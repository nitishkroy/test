import { Map } from 'immutable';
import {
  mudWeightSubscriptions,
  mudWeightMetadata,
} from 'hocs/mudWeight/withMudWeightWindowData/mudWeightSubscriptions';
import { ASSET_TYPES } from '~/constants/assets';

import { ORIENTATION_SETTINGS } from '~/constants/apps';

export const CATEGORY = 'wellboreStability';
export const NAME = 'mwWindow';
export const SUBSCRIPTIONS = [...mudWeightSubscriptions];
export const METADATA = {
  segment: ['drilling'],
  title: 'Real Time Mud Weight Window',
  settingsTitle: 'Real Time Mud Weight Window',
  subtitle:
    'The Real Time Mud Weight Window, with the ability to track ECD against Pore Pressure (Flow), Collapse, Loss, and Fracture ECD gradients.',
  appKey: 'wellboreStability-mwWindow',
  recordProvider: 'corva',
  recordCollections: {
    ...mudWeightMetadata.recordCollections,
  },
  developer: { name: 'Corva', url: 'http://www.corva.ai/' },
  version: 'v0.1',
  publishedAt: '2017-03-14T00:00:00',
  lightThemeReport: true,
};

export const PRIMARY_ASSET_TYPE = ASSET_TYPES.getIn(['rig', 'name']);
export const INITIAL_SIZE = { w: 6, h: 10 };

export const X_AXIS = {
  name: 'measured_depth',
  label: 'Measured Depth',
  scaleRef: 'measured_depth',
};

export const SUPPORTED_CHART_SERIES = {
  flow: {
    label: 'Flow',
    defaultColor: '#FF0000',
  },
  loss: {
    label: 'Loss',
    defaultColor: '#FCE883',
  },
  collapse: {
    label: 'Collapse',
    defaultColor: '#FFFF00',
  },
  fracture: {
    label: 'Fracture',
    defaultColor: '#FA8072',
  },
  safe: {
    label: 'Safe Zone',
    defaultColor: '#00FF00',
  },
  ecd: {
    label: 'Corva ECD',
    defaultColor: '#0093AF',
    type: 'line',
  },
  mud_density: {
    label: 'Mud Density',
    defaultColor: '#0018A8',
    type: 'line',
  },
  mud_plan: {
    label: 'Mud Plan',
    defaultColor: '#FA58F4',
    type: 'line',
  },
  mwd_ecd: {
    label: 'MWD ECD',
    defaultColor: '#FF0000',
    type: 'scatter',
  },
};

export const SCALE_OPTIONS = {
  measured_depth: {
    label: 'Measured Depth',
    unitType: 'length',
    unit: 'ft',
  },
};

export const DEFAULT_SCALE_SETTINGS = Object.entries(SCALE_OPTIONS).reduce(
  (settings, [key, scaleOption]) =>
    settings.set(`${key}_min`, scaleOption.min).set(`${key}_max`, scaleOption.max),
  Map()
);

export const DEFAULT_SETTINGS = {
  graphColors: Map(SUPPORTED_CHART_SERIES).map(({ defaultColor }) => defaultColor),
  scale: DEFAULT_SCALE_SETTINGS,
  orientation: ORIENTATION_SETTINGS[0].value,
  showFormations: false,
};

export const DYNAMIC_MENUS = {
  download: {
    icon: 'archive',
    title: 'Export as CSV',
    priority: false,
  },
};

export const CSV_TITLES = {
  depth: 'Depth',
  mwdEcd: 'MWD ECD',
  ecd: 'Corva ECD',
  mudDensity: 'Mud Density',
  mudPlan: 'Mud Plan',
  flow: 'Flow',
  collapse: 'Collapse',
  safe: 'Safe Zone',
  loss: 'Loss',
  fracture: 'Fracture',
};

export const FRACTURE_DEFAULT_VALUE = '-';
export const MWD_ECD_DEFAULT_VALUE = '-';