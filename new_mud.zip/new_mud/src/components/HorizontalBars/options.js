// All of the options below make the highchart to display specific styles/labels/ux interaction
// You can find all of the options available in Highcharts API Documantation
export const defaultHighchartsOptions = {
    chart: {
        backgroundColor: 'transparent',
        style: { color: '#9E9E9E', fontFamily: '"Roboto", "Helvetica", "Arial", sans-serif', fontSize: '11px', fontWeight: 'normal' },
        
        type: 'xrange',
        scrollablePlotArea: {
          minWidth : 5000,
          scrollPositionX : 1
        },
        height : '200px',
        pinchType: 'x',
        zoomType: 'x'
    },
    credits: { enabled: false },
    exporting: { enabled: false },
    labels: {
        color: '#9E9E9E'
    },
    legend: {
        itemHiddenStyle: { color: '#808080' },
        itemHoverStyle: { color: '#BDBDBD' },
        itemStyle: { color: '#BDBDBD', fontSize: '11px', fontWeight: 'normal' },
    },
    plotOptions: {
        xrange: {
          borderRadius: 3,
          borderWidth: 0,
          grouping: false,
          colorByPoint: false
        }
    },
    time: {
        useUTC: false
    },
    title: {
        text: ''
    },
    tooltip: {
        backgroundColor: 'rgba(59, 59, 59, 0.8)',
        borderRadius: 4,
        borderWidth: 1,
        // crosshairs: true,
        followPointer: true,
        
        shadow: false,
        shape: 'rect',
        style: { color: '#fff' },
        useHTML: true
    },
    xAxis: {
        title: { text: '' },
        type: 'datetime',
    },
    yAxis: {
        gridLineColor: '#414141', 
        height: '80px',
        title: {
            text: ''
        }
    },
}

export function getHighchartsOptions(series, categories) {
    
    return {
        ...defaultHighchartsOptions,
        chart: {
            ...defaultHighchartsOptions.chart,
            scrollablePlotArea: {
                ...defaultHighchartsOptions.chart.scrollablePlotArea,
            }
        },
        series,
        yAxis: {
            ...defaultHighchartsOptions.yAxis,
            categories
        }
    }
}