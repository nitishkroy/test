import { alerts as alertsConstants } from '@corva/ui/constants';

const { ALERT_LEVELS } = alertsConstants;

export const REQUIRED_CHANNELS = [
  {
    name: 'bit_depth',
    title: 'Bit Depth',
  },
  {
    name: 'hole_depth',
    title: 'Hole Depth',
  },
  {
    name: 'block_height',
    title: 'Block Height',
  },
  {
    name: 'weight_on_bit',
    title: 'Weight on Bit',
  },
  {
    name: 'rop',
    title: 'ROP',
  },
  {
    name: 'rotary_torque',
    title: 'Rotary Torque',
  },
  {
    name: 'rotary_rpm',
    title: 'Rotary RPM',
  },
  {
    name: 'diff_press',
    title: 'Differential Pressure',
  },
  {
    name: 'mud_flow_in',
    title: 'Mud Flow In',
  },
  {
    name: 'hook_load',
    title: 'Hook Load',
  },
  {
    name: 'standpipe_pressure',
    title: 'Standpipe Pressure',
  } /* {
  name: 'mud_volume',
  title: 'Mud Volume',
}, {
  name: 'mud_flow_out',
  title: 'Mud Flow Out',
} /* {
  name: 'gain_loss',
  title: 'Gain/loss',
} */,
];

export const STATE_CATEGORY_MAP = {
  'DrillRot(Rotary mode drilling)': 'Rotary Drilling',
  'Rotary Drilling': 'Rotary Drilling',
  'DrillSlide(Slide mode drilling)': 'Slide Drilling',
  'Slide Drilling': 'Slide Drilling',
  'Rih(Tripping in)': 'Run in Hole',
  'Run in Hole': 'Run in Hole',
  'RihPump(Sliding in)': 'Washing Down',
  'Washing Down': 'Washing Down',
  'RihRot(Tripping in)': 'Dry Reaming Down',
  'Dry Reaming Down': 'Dry Reaming Down',
  'RihPumpRot(Reaming in)': 'Reaming Down',
  'Reaming Down': 'Reaming Down',
  'Pooh(Tripping out)': 'Pull out of Hole',
  'Pull out of Hole': 'Pull out of Hole',
  'PoohPump(Sliding out)': 'Washing Up',
  'Washing Up': 'Washing Up',
  'PoohRot(Tripping out)': 'Dry Reaming Up',
  'Dry Reaming Up': 'Dry Reaming Up',
  'PoohPumpRot(Reaming out)': 'Reaming Up',
  'Reaming Up': 'Reaming Up',
  'Static(Off bottom)': 'Idle Off Bottom',
  'Idle Off Bottom': 'Idle Off Bottom',
  'Idle On Bottom': 'Idle On Bottom',
  'StaticPump(Circulating)': 'Circulating',
  Circulating: 'Circulating',
  'StaticRot(Off bottom Rot)': 'Dry Rotary Off Bottom',
  'Dry Rotary Off Bottom': 'Dry Rotary Off Bottom',
  'StaticPumpRot(Circulating&Rot)': 'Rotary Off Bottom',
  'Rotary Off Bottom': 'Rotary Off Bottom',
  'Onbottom(Static On bottom)': 'Static On Bottom',
  'Static On Bottom': 'Static On Bottom',
  'Static Off Bottom': 'Static Off Bottom',
  'OnbottomPump(Circulating On Bottom)': 'Circulating On Bottom',
  'Circulating On Bottom': 'Circulating On Bottom',
  'OnbottomRot(On bottom Rot)': 'Dry Rotary On Bottom',
  'Dry Rotary On Bottom': 'Dry Rotary On Bottom',
  'Circulating and Rot On Bottom': 'Circ. & Rot. On Bottom',
  'Circ. & Rot. On Bottom': 'Circ. & Rot. On Bottom',
  InSlips: 'In Slips',
  'In Slips': 'In Slips',
  CasingRunning: 'Running Casing',
  CasingTrippingIn: 'Casing Trip In',
  CementingAndWaiting: 'Cementing',
  Unclassified: 'Unclassified',
};

export const ACTIVITY_COLORS = {
  'Slide Drilling': '#0085e3',
  'Rotary Drilling': '#4840d1',
  'In Slips': '#909f98',
  Circulating: '#9500b7',
  'Run in Hole': '#f70000',
  'Pull out of Hole': '#940000',
  'Reaming Up': '#38732e',
  'Dry Reaming Up': '#2e7357',
  'Reaming Down': '#5dd94b',
  'Dry Reaming Down': '#4bd984',
  'Washing Up': '#efd34b',
  'Washing Down': '#e99100',
  'Idle Off Bottom': '#d2dfd8',
  'Dry Rotary Off Bottom': '#a55d84',
  'Rotary Off Bottom': '#f28ac2',
  'Idle On Bottom': '#d2dfd8',
  'Static On Bottom': '#d2dfd8',
  'Static Off Bottom': '#79827d',
  'Circulating On Bottom': '#2dc7d5',
  'Dry Rotary On Bottom': '#05a0ae',
  'Circ. & Rot. On Bottom': '#0cebff',
  'Running Casing': '#e837f3',
  'Casing Trip In': '#f8a2fd',
  Cementing: '#47c7cf',
  // Legacy data defines
  'Reaming Upwards': '#38732e',
  'Dry Reaming Upwards': '#2e7357',
  'Reaming Downwards': '#5dd94b',
  'Dry Reaming Downwards': '#4bd984',
  'Washing Upwards': '#efd34b',
  'Washing Downwards': '#e99100',
  'Drilling Slide': '#0085e3',
  'Drilling Rotary': '#4840d1',
  Connection: '#909f98',
  'Run out of Hole': '#940000',
  Other: '#d2dfd8',
  Unclassified: '#d2dfd8',
};

export const INFO_LEVEL = ALERT_LEVELS[0].value;
export const WARNING_LEVEL = ALERT_LEVELS[1].value;
export const CRITICAL_LEVEL = ALERT_LEVELS[2].value;

export const ALERT_COLORS = {
  [INFO_LEVEL]: '#86C2ED',
  [WARNING_LEVEL]: '#ffba00',
  [CRITICAL_LEVEL]: '#ff0000',
};

export const ALERT_LEVELS_ORDER = [CRITICAL_LEVEL, WARNING_LEVEL, INFO_LEVEL];

export const ASSET_STATUS_COLORS = {
  IDLE: '#9a9a9a',
  OPTIMAL: '#20db17',
  WARNING: '#ffba00',
  CRITICAL: 'red',
};

export const OPERATIONAL_NOTE_STATUS_COLORS = {
  info: null,
  warning: '#ffba00',
  critical: '#ff0000',
};

export const FONT_SIZES = [
  { label: 'Normal', value: 0 },
  { label: 'Large', value: 1 },
];

export const DRILLING_ACTIVITY = new Set(['Slide Drilling', 'Rotary Drilling']);

export const VALUES = {
  TWO_SECONDS: 2000, // NOTE: in milliseconds
  THIRTY_SECONDS: 30000, // NOTE: in milliseconds
  TEN_MINUTES: 600000, // NOTE: in milliseconds
  TWELVE_HOURS: 43200, // NOTE: in seconds
  TWENTY_FOUR_HOURS: 86400, // NOTE: in seconds
  THIRTY_DAYS: 2592000, // NOTE: in seconds
  TWO_DAYS: 172800, // NOTE: in seconds
  FEW_DAYS_DRILLING_DISTANCE: 1000, // NOTE: Depth of a few days of drilling
  MINIMUM_HOLE_DEPTH: 1000, // NOTE: Minimum hole depth at which surveys are usually taken
  TWO_AND_HALF_COMPLETE_DRILLING_STANDS: 300, // NOTE: In ft. A drilling stand = 90ft
};

export const DEFAULT_SETTINGS = {
  showAssetLink: true,
  showActivitySummary: true,
  ignoreROPWarning: false,
  moderateDataDelay: 15, // NOTE: in minutes
  severeDataDelay: 60, // NOTE: in minutes
  fontSize: FONT_SIZES[0].value,
};