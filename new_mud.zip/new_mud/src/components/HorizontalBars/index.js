import React, { useMemo } from 'react'
import Highcharts from 'highcharts'
import HighchartsReact from 'highcharts-react-official'

import { getHighchartsOptions } from './options'

export default function HorizontalBars({ data, categories }) {

  // using useMemo in React allow us to keep in storage specific states, let say X and Y
  // So if at t=0 we have state X, then at t=1 we have state Y, but then at t=2 we have once again state X
  // React will not "create" a new render, it will reuse the one create at t=0
  // and only will render new DOM if a new state appears, like state Z at t=n
  return useMemo(() => {
    const options = getHighchartsOptions(data, categories)
    
    return (  
        <HighchartsReact
            containerProps={{ style: { height: '100%', width: '100%' } }}
            highcharts={Highcharts}
            immutable
            options={options}
        />
    )
  }, [data])
}
