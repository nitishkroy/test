import PropTypes from 'prop-types';
import { compose } from 'redux';
import ImmutablePropTypes from 'react-immutable-proptypes';
import { withRouter } from 'react-router';
import { withStyles } from '@material-ui/core/styles';

import Typography from '@material-ui/core/Typography';

import { firstSubData } from '~/selectors/subscriptions';
import { formatLastDataUpdate } from '~/utils/time';

import { SUBSCRIPTIONS } from './meta';

import './AssetStatusApp.css';

const muiStyles = {
  lastUpdate: {
    color: 'rgb(200, 200, 200)',
    fontSize: 10,
  },
};

const AssetStatusAppFooter = ({ data, lastDataUpdate, router, classes }) => {
  const subData = firstSubData(data, SUBSCRIPTIONS);
  if (!subData) {
    return null;
  }

  const timestamp = subData.get('timestamp');
  // TODO: [CW-101] Add timezone to user settings and use it for reports
  const useCompanyTimezone = router.location.pathname.startsWith('/reports/');

  return (
    <div className="c-asset-status__footer">
      {lastDataUpdate && (
        <Typography variant="body2" className={classes.lastUpdate}>
          Last update: {formatLastDataUpdate(lastDataUpdate, useCompanyTimezone)}
        </Typography>
      )}
      {!lastDataUpdate && timestamp && (
        <Typography variant="body2" className={classes.lastUpdate}>
          Last update: {formatLastDataUpdate(timestamp, useCompanyTimezone)}
        </Typography>
      )}
    </div>
  );
};

AssetStatusAppFooter.propTypes = {
  lastDataUpdate: PropTypes.number,
  data: ImmutablePropTypes.map,

  classes: PropTypes.object.isRequired, // eslint-disable-line react/forbid-prop-types
};

AssetStatusAppFooter.defaultProps = {
  lastDataUpdate: undefined,
  data: undefined,
};

export default compose(withStyles(muiStyles), withRouter)(AssetStatusAppFooter);