import { PureComponent, Fragment } from 'react';
import PropTypes from 'prop-types';
import { compose } from 'redux';
import { withRouter } from 'react-router';
import toJS from 'react-immutable-hoc';
import { withStyles } from '@material-ui/core/styles';
import { groupBy, sortBy } from 'lodash';

import AlertWarningIcon from '@material-ui/icons/Warning';
import IconButton from '@material-ui/core/IconButton';
import Menu from '@material-ui/core/Menu';

import AssetStatusAlertMenuItem from './AssetStatusAlertMenuItem';

import { ALERT_COLORS, ALERT_LEVELS_ORDER } from './constants';

import './AssetStatusClosedAlerts.css';

const muiStyles = {
  iconButton: {
    '&:hover': {
      backgroundColor: 'transparent',
    },
    height: 36,
    width: 'auto',
    padding: 0,
    display: 'flex',
    alignItems: 'center',
    fontSize: '1.25rem',
    fontWeight: 'bold',
    marginLeft: 15,
    cursor: 'pointer',
  },
  popover: {
    maxHeight: 300,
  },
};

class AssetStatusClosedAlerts extends PureComponent {
  constructor(props) {
    super(props);

    this.state = {
      menuAnchor: null,
      openedDialogId: null,
    };
  }

  get alertGroups() {
    const filteredAlerts = this.props.alerts.filter(alert => alert.status === 'closed');
    const groupedAlerts = groupBy(filteredAlerts, alert => alert.alert_definition.level);
    return sortBy(Object.entries(groupedAlerts), ([level]) => ALERT_LEVELS_ORDER.indexOf(level));
  }

  handleMenuClick = (event, openedDialogId) =>
    this.setState({ menuAnchor: event.currentTarget, openedDialogId });

  handleClose = () => this.setState({ menuAnchor: null });

  renderAlert = alert => (
    <AssetStatusAlertMenuItem
      alert={alert}
      appId={this.props.appId}
      key={alert.id}
      setHiddenAlerts={this.props.setHiddenAlerts}
    />
  );

  renderAlertGroup = ([level, alerts]) => (
    <Fragment key={level}>
      <IconButton
        disableRipple
        classes={{ root: this.props.classes.iconButton }}
        aria-owns={this.state.menuAnchor ? `${level}-alerts-menu` : undefined}
        aria-haspopup="true"
        onClick={e => this.handleMenuClick(e, level)}
      >
        <div className="c-asset-status__icon-wrapper">
          <AlertWarningIcon htmlColor={ALERT_COLORS[level]} />
        </div>
        <div className="c-asset-status__icon-counter" style={{ color: ALERT_COLORS[level] }}>
          {alerts.length}
        </div>
      </IconButton>
      <Menu
        id={`${level}-alerts-menu`}
        anchorEl={this.state.menuAnchor}
        open={Boolean(this.state.menuAnchor) && this.state.openedDialogId === level}
        onClose={this.handleClose}
        PopoverClasses={{
          paper: this.props.classes.popover,
        }}
      >
        {alerts.map(this.renderAlert)}
      </Menu>
    </Fragment>
  );

  renderAlertGroups = groups => (
    <div className="c-asset-status__closed-alerts-container">
      <div>Alerts</div>
      {groups.map(this.renderAlertGroup)}
    </div>
  );

  render() {
    const groups = this.alertGroups;
    return groups.length ? this.renderAlertGroups(groups) : null;
  }
}

AssetStatusClosedAlerts.propTypes = {
  alerts: PropTypes.arrayOf(PropTypes.object.isRequired).isRequired,
  classes: PropTypes.object.isRequired, // eslint-disable-line react/forbid-prop-types
  appId: PropTypes.number.isRequired,
  setHiddenAlerts: PropTypes.func.isRequired,
};

export default compose(toJS, withRouter, withStyles(muiStyles))(AssetStatusClosedAlerts);