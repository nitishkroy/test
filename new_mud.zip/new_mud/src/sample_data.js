export const sample_data = [
    {
        "_id": "61709d7836b0c1ea59bd3256",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 6,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765642,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d7836b0c1ea59bd3257",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": -2,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765644,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d7836b0c1ea59bd3258",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": -1,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765646,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d7836b0c1ea59bd3259",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 4,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765648,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d7836b0c1ea59bd325a",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 1,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765650,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d7836b0c1ea59bd325b",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": -1,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765652,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d7836b0c1ea59bd325c",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": -2,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765654,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d7836b0c1ea59bd325d",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 1,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765656,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d7836b0c1ea59bd325e",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 5,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765658,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d794fe3a4586317c858",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 5,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765660,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d794fe3a4586317c859",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": -2,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765662,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d794fe3a4586317c85a",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": -1,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765664,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d794fe3a4586317c85b",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 2,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765666,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d794fe3a4586317c85c",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 3,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765668,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d794fe3a4586317c85d",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 3,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765670,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d794fe3a4586317c85e",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 2,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765672,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d794fe3a4586317c85f",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 2,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765674,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d794fe3a4586317c860",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": -1,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765676,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d79042b6d75f45a956a",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": -6,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765678,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d79042b6d75f45a956b",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": -6,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765679,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d79042b6d75f45a956c",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 1,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765682,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d79042b6d75f45a956d",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 2,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765684,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d79042b6d75f45a956e",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 3,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765686,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d79042b6d75f45a956f",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 2,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765688,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d79042b6d75f45a9570",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 3,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765690,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d79042b6d75f45a9571",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 2,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765692,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d79042b6d75f45a9572",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": -1,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765694,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d79042b6d75f45a9573",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 4,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765696,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d7d4fe3a4586317c861",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": -1,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765698,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d7d4fe3a4586317c862",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": -1,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765700,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d7d4fe3a4586317c863",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 1,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765702,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d7d4fe3a4586317c864",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 3,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765704,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d7d4fe3a4586317c865",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 3,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765706,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d7d4fe3a4586317c866",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 2,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765708,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d7d4fe3a4586317c867",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": -1,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765710,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d7d4fe3a4586317c868",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": -2,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765712,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d7d4fe3a4586317c869",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 4,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765714,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d7d4fe3a4586317c86a",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 4,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765716,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d7df3094312cc052469",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 5,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765718,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d7eaace03ac50e48214",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": -1,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765720,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d7eaace03ac50e48215",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 4,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765722,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d7eaace03ac50e48216",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 3,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765724,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d7eaace03ac50e48217",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": -3,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765726,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d7eaace03ac50e48218",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 2,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765728,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d7eaace03ac50e48219",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 0,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765730,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d7eaace03ac50e4821a",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": -3,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765732,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d7eaace03ac50e4821b",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 2,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765734,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d7eaace03ac50e4821c",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 2,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765736,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d7e4fe3a4586317c86b",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": -2,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765738,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d7e4fe3a4586317c86c",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": -1,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765740,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d7e4fe3a4586317c86d",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 1,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765742,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d7e4fe3a4586317c86e",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 2,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765744,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d7e4fe3a4586317c86f",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 3,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765746,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d7e4fe3a4586317c870",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 2,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765748,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d7e4fe3a4586317c871",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": -1,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765750,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d7e4fe3a4586317c872",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": -1,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765752,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d7e4fe3a4586317c873",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 2,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765754,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d7e4fe3a4586317c874",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": -1,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765756,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d7e5ea158de03e89ea3",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 2,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765758,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d7e5ea158de03e89ea4",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 4,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765760,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d7ff3094312cc05246a",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": -2,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765762,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d7ff3094312cc05246b",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 2,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765764,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d7ff3094312cc05246c",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 2,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765766,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d7ff3094312cc05246d",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": -1,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765768,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d7ff3094312cc05246e",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 2,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765770,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d7ff3094312cc05246f",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": -1,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765772,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d7ff3094312cc052470",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 2,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765774,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d7ff3094312cc052471",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 4,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765776,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d7ff3094312cc052472",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 1,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765778,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d7f042b6d75f45a9574",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 5,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765780,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d7f042b6d75f45a9575",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 4,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765782,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d7f042b6d75f45a9576",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": -2,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765784,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d7f042b6d75f45a9577",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 5,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765786,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d7f042b6d75f45a9578",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 4,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765788,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d7f042b6d75f45a9579",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 4,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765790,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d7f042b6d75f45a957a",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 2,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765792,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d7f042b6d75f45a957b",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": -2,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765794,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d7f042b6d75f45a957c",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 4,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765796,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d7f042b6d75f45a957d",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 5,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765798,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d80d5294c6858d9b383",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 2,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765800,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d80d5294c6858d9b384",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": -1,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765802,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d80d5294c6858d9b385",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 3,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765804,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d80d5294c6858d9b386",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 1,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765806,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d80d5294c6858d9b387",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 2,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765808,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d80d5294c6858d9b388",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 3,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765810,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d80d5294c6858d9b389",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 1,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765812,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d80d5294c6858d9b38a",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 1,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765814,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d80d5294c6858d9b38b",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 5,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765816,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d80d5294c6858d9b38c",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 1,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765818,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d80042b6d75f45a957e",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 5,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765820,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d80d5294c6858d9b38d",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 3,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765822,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d80d5294c6858d9b38e",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": -3,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765824,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d80d5294c6858d9b38f",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 2,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765826,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d80d5294c6858d9b390",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 0,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765828,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d80d5294c6858d9b391",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 2,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765830,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d80d5294c6858d9b392",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 2,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765832,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d80d5294c6858d9b393",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": -2,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765834,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d80d5294c6858d9b394",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 4,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765836,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d80d5294c6858d9b395",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 2,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765838,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d80d5294c6858d9b396",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 2,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765840,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d82c70b488e15fc3a49",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": -2,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765842,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d82c70b488e15fc3a4a",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": -2,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765844,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d82c70b488e15fc3a4b",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": -1,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765846,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d82c70b488e15fc3a4c",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": -1,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765848,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d82c70b488e15fc3a4d",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 3,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765850,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d82c70b488e15fc3a4e",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 2,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765852,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d82c70b488e15fc3a4f",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 2,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765854,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d82c70b488e15fc3a50",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": -1,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765856,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d82c70b488e15fc3a51",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": -2,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765858,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d82c70b488e15fc3a52",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": -1,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765860,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d82aace03ac50e4821d",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": -1,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765862,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d82d464e95458ea34bd",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 4,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765864,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d82d464e95458ea34be",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 4,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765866,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d82d464e95458ea34bf",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 4,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765868,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d82d464e95458ea34c0",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": -2,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765870,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d82d464e95458ea34c1",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 1,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765872,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d82d464e95458ea34c2",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": -1,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765874,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d82d464e95458ea34c3",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 3,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765876,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d82d464e95458ea34c4",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 3,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765878,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d82d464e95458ea34c5",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 3,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765880,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d83ebe2bb8f8dc06924",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 2,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765882,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d83ebe2bb8f8dc06925",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": -2,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765884,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d83ebe2bb8f8dc06926",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": -1,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765886,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d83ebe2bb8f8dc06927",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 1,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765888,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d83ebe2bb8f8dc06928",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": -1,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765890,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d83ebe2bb8f8dc06929",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 2,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765892,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d83ebe2bb8f8dc0692a",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 4,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765894,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d83ebe2bb8f8dc0692b",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 1,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765896,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d83ebe2bb8f8dc0692c",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": -1,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765898,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709d83ebe2bb8f8dc0692d",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 5,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765900,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709f0936b0c1ea59bd341b",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 1,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765902,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709f0936b0c1ea59bd341c",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 2,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765904,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709f0936b0c1ea59bd341d",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 4,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765906,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709f0936b0c1ea59bd341e",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 5,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765908,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709f0936b0c1ea59bd341f",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": -2,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765910,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709f0936b0c1ea59bd3420",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": -1,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765912,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709f0936b0c1ea59bd3421",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": -1,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765914,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709f0936b0c1ea59bd3422",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 1,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765916,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709f0936b0c1ea59bd3423",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": -2,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765918,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709f0936b0c1ea59bd3424",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": -3,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765920,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709f09ebe2bb8f8dc06b1a",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": -1,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765922,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709f095ea158de03e89f97",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 3,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765924,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709f095ea158de03e89f98",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 2,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765926,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709f095ea158de03e89f99",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 5,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765928,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709f095ea158de03e89f9a",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 3,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765930,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709f095ea158de03e89f9b",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": -1,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765932,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709f095ea158de03e89f9c",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 4,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765934,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709f095ea158de03e89f9d",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 2,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765936,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709f095ea158de03e89f9e",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 2,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765938,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709f095ea158de03e89f9f",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": -2,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765940,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709f095ea158de03e89fa0",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 2,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765942,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709f0ac70b488e15fc3cd7",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 4,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765944,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709f0ac70b488e15fc3cd8",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": -1,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765946,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709f0ac70b488e15fc3cd9",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 1,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765948,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709f0ac70b488e15fc3cda",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 4,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765950,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709f0ac70b488e15fc3cdb",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": -2,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765952,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709f0ac70b488e15fc3cdc",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 6,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765954,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709f0ac70b488e15fc3cdd",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": -1,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765956,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709f0ac70b488e15fc3cde",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": -1,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765958,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709f0aebe2bb8f8dc06b1c",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 1,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765960,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709f0aebe2bb8f8dc06b1d",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 6,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765962,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709f0aebe2bb8f8dc06b1e",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": -3,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765964,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709f0aebe2bb8f8dc06b1f",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": -3,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765966,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709f0aebe2bb8f8dc06b20",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 1,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765968,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709f0aebe2bb8f8dc06b21",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 4,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765970,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709f0aebe2bb8f8dc06b22",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 4,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765972,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709f0aebe2bb8f8dc06b23",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 4,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765974,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709f0aebe2bb8f8dc06b24",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 4,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765976,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709f0aebe2bb8f8dc06b25",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 4,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765978,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709f0aebe2bb8f8dc06b26",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": -4,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765980,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709f0aebe2bb8f8dc06b27",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": -3,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765982,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709f0b36b0c1ea59bd3425",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": -3,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765984,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709f0b36b0c1ea59bd3426",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 2,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765986,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709f0b36b0c1ea59bd3427",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": -2,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765988,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709f0b36b0c1ea59bd3428",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 5,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765990,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709f0b36b0c1ea59bd3429",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": -1,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765992,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709f0b36b0c1ea59bd342a",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 2,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765994,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709f0b36b0c1ea59bd342b",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 2,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765996,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709f0b36b0c1ea59bd342c",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": -1,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634765998,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709f0b36b0c1ea59bd342d",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": -1,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634766000,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709f0b36b0c1ea59bd342e",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": -2,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634766002,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709f0b36b0c1ea59bd342f",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 2,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634766004,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709f0b36b0c1ea59bd3430",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": -1,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634766006,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709f0b36b0c1ea59bd3431",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": -1,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634766008,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709f0b36b0c1ea59bd3432",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 2,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634766010,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709f0b36b0c1ea59bd3433",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": -1,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634766012,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709f0b36b0c1ea59bd3434",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 1,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634766014,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709f0b36b0c1ea59bd3435",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 1,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634766016,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709f0bd464e95458ea3627",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": -1,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634766018,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709f18c70b488e15fc3ce9",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 4,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634766021,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709f18c70b488e15fc3cea",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 1,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634766023,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709f18c70b488e15fc3ceb",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 4,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634766025,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709f18c70b488e15fc3cec",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": -1,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634766027,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709f18c70b488e15fc3ced",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 3,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634766029,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709f18c70b488e15fc3cee",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 3,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634766031,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709f18c70b488e15fc3cef",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 5,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634766033,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709f18c70b488e15fc3cf0",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 5,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634766035,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709f18c70b488e15fc3cf1",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 5,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634766037,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709f18c70b488e15fc3cf2",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": -1,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634766039,
        "app_key": "corva.digital_mud_engineer"
    },
    {
        "_id": "61709f185ea158de03e89fa1",
        "company_id": 81,
        "asset_id": 52505269,
        "version": 1,
        "provider": "corva",
        "collection": "digital-mud-engineer",
        "data": {
            "mud_flow_in": 241.467,
            "mud_flow_out": 1,
            "flowin_flowout": 4,
            "active_pit": null,
            "overall": null
        },
        "timestamp": 1634766041,
        "app_key": "corva.digital_mud_engineer"
    }
]