import { Component } from 'react';
import PropTypes from 'prop-types';
import ImmutablePropTypes from 'react-immutable-proptypes';
import moment from 'moment';
import ReactTooltip from 'react-tooltip';
import get from 'lodash/get';

import { getUnitDisplay, convertValue } from '@corva/ui/utils';

import * as csvExport from 'components/csvExporter';
import { LoadingIndicator } from '@corva/ui/components';
import TrendChart from 'components/highcharts/TrendChart';

import {
  mudWeightDataShape,
  withMudWeightWindowData,
} from 'hocs/mudWeight/withMudWeightWindowData/withMudWeightWindowData';
import utils from '~/utils';

import './mwWindowApp.css';

import {
  SUPPORTED_CHART_SERIES,
  X_AXIS,
  SCALE_OPTIONS,
  DEFAULT_SETTINGS,
  DYNAMIC_MENUS,
  CSV_TITLES,
  FRACTURE_DEFAULT_VALUE,
  MWD_ECD_DEFAULT_VALUE,
} from './constants';

const dividerStyle = {
  left: 0,
  right: 0,
  border: '1px solid white',
  top: '50%',
  position: 'absolute',
};

const barStyle = {
  position: 'absolute',
  paddingLeft: 2,
  paddingRight: 2,
};

const innerBarStyle = {
  width: '100%',
  height: '100%',
  maxWidth: 25,
  marginLeft: 'auto',
  marginRight: 'auto',
};

const tooltipStyle = {
  fontSize: '0.9rem',
  lineHeight: '1rem',
};

const MSG_OK = 'ok';
const MSG_LOADING = 'loading';

class mwWindowApp extends Component {
  constructor(props) {
    super(props);
    this.state = {
      scale: this.convertScale(props.scale),
    };
  }

  componentDidMount() {
    this.toggleDynamicMenuItems(true);
  }

  componentWillUnmount() {
    this.toggleDynamicMenuItems(false);
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    if (!nextProps.scale.equals(this.props.scale)) {
      this.setState({
        scale: this.convertScale(nextProps.scale),
      });
    }
  }

  get automaticOrientation() {
    return this.props.orientation === 'auto';
  }

  get horizontal() {
    return this.props.orientation === 'horizontal';
  }

  toggleDynamicMenuItems(showDynamicItems) {
    if (showDynamicItems) {
      const dynamicMenus = { ...DYNAMIC_MENUS };
      dynamicMenus.download.onClick = this.downloadCSV;
      this.props.registerMenuItems(dynamicMenus);
    } else {
      this.props.registerMenuItems([]);
    }
  }

  normalizeValueForCSVExport = value => (Number.isFinite(value) ? value.fixFloat(2) : '--');

  downloadCSV = () => {
    const fracture = get(this.props, 'mudWeightData.fracture', FRACTURE_DEFAULT_VALUE);
    const mwdEcd = get(this.props, 'mudWeightData.mwdEcd', MWD_ECD_DEFAULT_VALUE);

    const keysTable = Object.fromEntries(
      Object.entries(CSV_TITLES).map(([key, value]) => [value, key])
    );

    const normalizedData = this.getSeries()
      .concat({
        name: CSV_TITLES.fracture,
        data: fracture,
      })
      .reduce((acc, areaRange) => {
        const { data, name } = areaRange;
        const metric = keysTable[name];

        if (data) {
          data.forEach(record => {
            const [depth, value] = record;

            if (!(depth in acc)) {
              acc[depth] = {
                depth,
                mwdEcd,
              };
            }

            acc[depth][metric] = value;
          });
        }

        return acc;
      }, {});

    const dataForExport = Object.values(normalizedData)
      .map(record => ({
        depth: record.depth.toFixed(2),
        mwdEcd: this.normalizeValueForCSVExport(record.mwdEcd),
        ecd: this.normalizeValueForCSVExport(record.ecd),
        mudDensity: this.normalizeValueForCSVExport(record.mudDensity),
        mudPlan: this.normalizeValueForCSVExport(record.mudPlan),
        flow: this.normalizeValueForCSVExport(record.flow),
        collapse: this.normalizeValueForCSVExport(record.collapse),
        safe: this.normalizeValueForCSVExport(record.safe),
        loss: this.normalizeValueForCSVExport(record.loss),
        fracture: this.normalizeValueForCSVExport(record.fracture),
      }))
      .sort((recordA, recordB) => parseFloat(recordA.depth) - parseFloat(recordB.depth));

    const lengthUnit = getUnitDisplay('length');
    const densityUnit = getUnitDisplay('density');

    const csvData = csvExport.convertJsonToCsv(dataForExport, {
      depth: `${CSV_TITLES.depth} (${lengthUnit})`,
      mwdEcd: `${CSV_TITLES.mwdEcd} (${densityUnit})`,
      ecd: `${CSV_TITLES.ecd} (${densityUnit})`,
      mudDensity: `${CSV_TITLES.mudDensity} (${densityUnit})`,
      mudPlan: `${CSV_TITLES.mudPlan} (${densityUnit})`,
      flow: `${CSV_TITLES.flow} Corva ECD (${densityUnit})`,
      collapse: `${CSV_TITLES.collapse} Corva ECD (${densityUnit})`,
      safe: `${CSV_TITLES.safe} Corva ECD (${densityUnit})`,
      loss: `${CSV_TITLES.loss} Corva ECD (${densityUnit})`,
      fracture: `${CSV_TITLES.fracture} Corva ECD`,
    });

    csvExport.downloadFile('Real Time Mud Weight Window.csv', csvData);
  };

  getYAxes = () => {
    const {
      mudWeightData: { safeMin, safeMax, maxEcd, mudDensityVal },
    } = this.props;

    const onePPG = parseInt(convertValue(1, 'density', 'ppg'), 10);
    const yMin = parseInt(utils.mathMin(safeMin, mudDensityVal), 10) - onePPG;
    const yMax = parseInt(utils.mathMax(safeMax, maxEcd), 10) + onePPG;

    return [
      {
        color: '#fff',
        others: {
          opposite: false,
          min: yMin,
          max: yMax,
          endOnTick: true,
          startOnTick: true,
        },
        titleText: `Pressure Gradient (${getUnitDisplay('density')})`,
      },
    ];
  };

  getSeriesColor(field) {
    if (this.props.graphColors.has(field)) {
      return this.props.graphColors.get(field);
    }
    return SUPPORTED_CHART_SERIES[field].defaultColor;
  }

  getSeries = () => {
    const {
      flow,
      loss,
      collapse,
      fracture,
      ecds,
      safe,
      mudDensity,
      mudPlan,
      mwdEcd,
      bitDepth,
    } = this.props.mudWeightData;

    const commonSetting = {
      yAxis: 0,
      turboThreshold: 10000,
      fillOpacity: 1,
      type: 'arearange',
      marker: { enabled: false },
    };

    const isFractureAvailable = fracture.length > 0;

    const fractureS = {
      ...commonSetting,
      name: SUPPORTED_CHART_SERIES.fracture.label,
      color: this.getSeriesColor('fracture'),
      data: fracture,
    };
    const lossS = {
      ...commonSetting,
      name: SUPPORTED_CHART_SERIES.loss.label,
      color: this.getSeriesColor('loss'),
      data: loss,
    };
    const safeS = {
      ...commonSetting,
      name: SUPPORTED_CHART_SERIES.safe.label,
      color: this.getSeriesColor('safe'),
      data: safe,
    };
    const flowS = {
      ...commonSetting,
      name: SUPPORTED_CHART_SERIES.flow.label,
      color: this.getSeriesColor('flow'),
      data: flow,
    };
    const collapseS = {
      ...commonSetting,
      name: SUPPORTED_CHART_SERIES.collapse.label,
      color: this.getSeriesColor('collapse'),
      data: collapse,
    };
    const ecdS = {
      ...commonSetting,
      name: SUPPORTED_CHART_SERIES.ecd.label,
      color: this.getSeriesColor('ecd'),
      type: 'line',
      lineWidth: 3,
      data: ecds,
    };
    const mudDensityS = {
      ...commonSetting,
      name: SUPPORTED_CHART_SERIES.mud_density.label,
      color: this.getSeriesColor('mud_density'),
      type: 'line',
      dashStyle: 'dash',
      data: mudDensity,
    };
    const mudPlanS = {
      ...commonSetting,
      name: SUPPORTED_CHART_SERIES.mud_plan.label,
      color: this.getSeriesColor('mud_plan'),
      type: 'line',
      dashStyle: 'dash',
      data: mudPlan,
    };
    const mwdEcdS = {
      name: SUPPORTED_CHART_SERIES.mwd_ecd.label,
      type: 'scatter',
      data: [[bitDepth, mwdEcd]],
      marker: {
        symbol: 'cross',
        lineColor: this.getSeriesColor('mwd_ecd'),
        lineWidth: 5,
        radius: 10,
      },
    };

    let allSeries = [lossS, safeS, collapseS, flowS, ecdS, mudDensityS, mudPlanS];
    if (isFractureAvailable) {
      allSeries = [fractureS, ...allSeries];
    }
    if (mwdEcd) {
      allSeries = [...allSeries, mwdEcdS];
    }
    return allSeries;
  };

  getPlotLines = () => {
    const {
      mudWeightData: { casingDepth },
      formations,
    } = this.props;
    const defaultPlots = [
      {
        color: '#AAA',
        width: 3,
        value: casingDepth,
        zIndex: 20,
        label: {
          text: 'Casing',
          style: {
            color: '#cccccc',
            fontWeight: 'bold',
          },
        },
      },
    ];

    return this.props.showFormations
      ? formations.reduce(
          (formationPlots, item) => [
            ...formationPlots,
            {
              color: '#000',
              width: 3,
              value: convertValue(item.getIn(['data', 'md']), 'length', 'ft'),
              zIndex: 20,
              label: {
                text: item.getIn(['data', 'formation_name']),
                style: {
                  color: '#000',
                  fontWeight: 'bold',
                },
              },
            },
          ],
          defaultPlots
        )
      : defaultPlots;
  };

  getXScaleValue = (name, minOrMax) => {
    if (!SCALE_OPTIONS[name]) return undefined;
    const scaleVal = this.state.scale.get(`${name}_${minOrMax}`);
    // Highchart works weird in case min/max value is 0.
    return scaleVal === 0 ? scaleVal + 0.1 : scaleVal;
  };

  convertScale = scale =>
    Object.entries(SCALE_OPTIONS).reduce((scaleSettings, [key, scaleOption]) => {
      const { unitType, unit } = scaleOption;
      const storedMin = scaleSettings.get(`${key}_min`);
      const storedMax = scaleSettings.get(`${key}_max`);
      const minValue = Number.isFinite(storedMin) ? storedMin : scaleOption.min;
      const maxValue = Number.isFinite(storedMax) ? storedMax : scaleOption.max;
      const cMinValue = unitType && unit ? convertValue(minValue, unitType, unit) : minValue;
      const cMaxValue = unitType && unit ? convertValue(maxValue, unitType, unit) : maxValue;
      return scaleSettings.set(`${key}_min`, cMinValue).set(`${key}_max`, cMaxValue);
    }, scale);

  renderAlert = (alert, idx, array) => {
    const alertType = alert.getIn(['data', 'alerts', 'main_alert']);
    const timestamp = alert.get('timestamp');
    const date = Number.isFinite(timestamp)
      ? moment.unix(timestamp).format('MM/DD hh:mm:ss a')
      : '-';
    const dataSize = array.size;
    const widthPercent = (1 / dataSize) * 100;
    const tooltipPlacement = idx < dataSize / 2 ? 'right' : 'left';
    const alertlength = convertValue(
      alert.getIn(['data', 'alerts', `${alertType}_length`]),
      'length',
      'ft'
    );
    let color;
    let direction;

    switch (alertType) {
      case 'collapse':
        direction = -1;
        color = this.getSeriesColor('collapse');
        break;
      case 'flow':
        direction = -1;
        color = this.getSeriesColor('flow');
        break;
      case 'fracture':
        direction = 1;
        color = this.getSeriesColor('fracture');
        break;
      case 'loss':
        direction = 1;
        color = this.getSeriesColor('loss');
        break;
      default:
        color = this.getSeriesColor('safe');
        direction = 1;
        break;
    }
    return (
      <div
        key={idx}
        style={{
          ...barStyle,
          left: `${idx * widthPercent}%`,
          top: direction === 1 ? '0%' : '50%',
          width: `${widthPercent}%`,
          height: '50%',
        }}
        data-tip
        data-for={`t-${timestamp}`}
        data-place={tooltipPlacement}
      >
        <div style={{ ...innerBarStyle, backgroundColor: color }} />
        <ReactTooltip id={`t-${timestamp}`} effect="float" type="dark">
          <div style={tooltipStyle}>
            <div> {alertType ? alertType.toUpperCase() : '-'} </div>
            <div> Date: {date} </div>
            <div> Length: {Number.isFinite(alertlength) ? alertlength.fixFloat(1) : '-'} </div>
          </div>
        </ReactTooltip>
      </div>
    );
  };

  renderAlerts = () => {
    const { alerts } = this.props;
    return (
      <div className="c-mw-window__alerts">
        {alerts.map(this.renderAlert)}
        <div style={dividerStyle} />
      </div>
    );
  };

  renderError = () => (
    <div className="c-app-container__content">
      <div className="c-app-container__error">
        <div className="c-app-container__error-grid">
          <div className="c-app-container__error-inner">
            <div className="c-app-container__error_no-data">
              <i className="material-icons">info_outline</i>
            </div>
            <h1>No Data</h1>
          </div>
        </div>
      </div>
    </div>
  );

  render() {
    const { error } = this.props;
    if (error !== MSG_OK) {
      if (error === MSG_LOADING) {
        return <LoadingIndicator />;
      }
      return this.renderError();
    }

    const {
      flowrate,
      currentEcd,
      spp,
      rop,
      predictedBottomHolePressure,
    } = this.props.mudWeightData;
    const xMinValue = this.getXScaleValue(X_AXIS.scaleRef, 'min');
    const xMaxValue = this.getXScaleValue(X_AXIS.scaleRef, 'max');
    const xAxisTitle = `${X_AXIS.label} (${getUnitDisplay('length')})`;
    const series = this.getSeries();

    return (
      <div className="c-mw-window">
        <div className="c-mw-window__info">
          <div className="c-mw-window__info-flowrate">
            <span>Flowrate: </span>
            {Number.isFinite(flowrate)
              ? `${flowrate.fixFloat(1)} (${getUnitDisplay('volumeFlowRate')})`
              : '-'}
            <span>{flowrate < this.minFlowrate ? '(Pumps Off)' : '(Pumps On)'}</span>
          </div>
          <div className="c-mw-window__info-ecd">
            <span>Corva ECD: </span>
            {Number.isFinite(currentEcd)
              ? `${currentEcd.fixFloat(2)} (${getUnitDisplay('density')})`
              : '-'}
          </div>
          <div className="c-mw-window__info-spp">
            <span>SPP: </span>
            {Number.isFinite(spp) ? `${spp.fixFloat(2)} (${getUnitDisplay('pressure')})` : '-'}
          </div>
          <div className="c-mw-window__info-rop">
            <span>ROP: </span>
            {Number.isFinite(rop) ? `${rop.fixFloat(2)} (${getUnitDisplay('velocity')})` : '-'}
          </div>
          <div className="c-mw-window__info-pbhp">
            <span>Predicted Bottom Hole Pressure: </span>
            {Number.isFinite(predictedBottomHolePressure)
              ? `${predictedBottomHolePressure.fixFloat(2)} (${getUnitDisplay('pressure')})`
              : '-'}
          </div>
        </div>
        <div className="c-mw-window__main">
          <TrendChart
            /* FIXME: fix trendChart.js to be able to handle dynamic xAxisPlotLines */
            key={this.props.showFormations}
            coordinates={this.props.coordinates}
            automaticOrientation={this.automaticOrientation}
            horizontal={this.horizontal}
            series={series}
            xAxisTitle={xAxisTitle}
            xAxisPlotLines={this.getPlotLines()}
            yAxes={this.getYAxes()}
            xMinValue={xMinValue}
            xMaxValue={xMaxValue}
            showLegend
            showXAxisLabels
          />
        </div>
        {!this.props.alerts.isEmpty() && this.renderAlerts()}
      </div>
    );
  }
}

mwWindowApp.propTypes = {
  mudWeightData: mudWeightDataShape,
  alerts: ImmutablePropTypes.list.isRequired,
  formations: PropTypes.array.isRequired, // eslint-disable-line
  error: PropTypes.string.isRequired,
  coordinates: ImmutablePropTypes.mapContains({
    h: PropTypes.number.isRequired,
    w: PropTypes.number.isRequired,
    x: PropTypes.number.isRequired,
    y: PropTypes.number.isRequired,
    pixelHeight: PropTypes.number.isRequired,
    pixelWidth: PropTypes.number.isRequired,
  }).isRequired,
  scale: ImmutablePropTypes.map,
  orientation: PropTypes.string,
  graphColors: ImmutablePropTypes.map,
  showFormations: PropTypes.bool,
  registerMenuItems: PropTypes.func.isRequired,
};

mwWindowApp.defaultProps = {
  scale: DEFAULT_SETTINGS.scale,
  mudWeightData: null,
  orientation: DEFAULT_SETTINGS.orientation,
  graphColors: DEFAULT_SETTINGS.graphColors,
  showFormations: DEFAULT_SETTINGS.showFormations,
};

export default withMudWeightWindowData(mwWindowApp);