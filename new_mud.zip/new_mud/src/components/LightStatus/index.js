import React from 'react'
import { Container, Circle } from './styled'
import { STATUS_INFO } from '../../constants'

export default function LightStatus(props) {

    return (
        <Container>
            <Circle bgColor={STATUS_INFO[props.status].color}></Circle>
            <span>{STATUS_INFO[props.status].label}</span>
        </Container>
    )
}
