const defaultHighchartsOptions = {
    chart: {
        backgroundColor: 'transparent',
        plotBackgroundColor: '#191919',
        style: { color: '#9E9E9E', fontFamily: '"Roboto", "Helvetica", "Arial", sans-serif', fontSize: '11px', fontWeight: 'normal' },
    },
    credits: { enabled: false },
    exporting: { enabled: false },
    labels: {
        color: '#9E9E9E'
    },
    legend: {
        itemHiddenStyle: { opacity: 0.6 },
        itemHoverStyle: { color: '#9E9E9E', opacity: 1 },
        itemStyle: { fontSize: '11px', fontWeight: 'normal', color: '#9E9E9E', opacity: 0.8 },
        symbolRadius: 3,
        symbolHeight: 10,
        symbolWidth: 10,
        useHTML: true
    },
    plotOptions: {
        series: {
            lineWidth: 2
        },
        scatter: {
            lineWidth: 0,
            marker: {
                radius: 5,
                states: {
                    hover: {
                        enabled: true,
                        // lineColor: 'rgb(100,100,100)'
                    }
                },
                symbol: 'circle'
            },
            states: {
                hover: {
                    marker: {
                        enabled: false
                    }
                }
            },
            tooltip: {
                headerFormat: '<b>{series.name}</b><br>',
                pointFormat: '{point.x} ft, {point.y} ft-klbf'
            }
        }
    },
    responsive: {
        rules: [{
            condition: {
                maxWidth: 500
            },
            chartOptions: {
                legend: {
                    layout: 'horizontal',
                    align: 'center',
                    verticalAlign: 'bottom'
                }
            }
        }]
    },
    time: {
        useUTC: false
    },
    tooltip: {
        backgroundColor: 'rgba(59, 59, 59, 0.8)',
        borderColor: '#03BCD4',
        borderRadius: 4,
        borderWidth: 1,
        crosshairs: true,
        shadow: false,
        shared: true,
        style: { color: '#fff' },
        useHTML: true,
        valueDecimals: 2,
        xDateFormat: '%m/%d/%Y %I:%M:%S %p'
    },
    xAxis: {
        gridLineWidth: 0, 
        lineWidth: 0,
        tickWidth: 0,
        title: { 
            style: { color: '#9E9E9E', fontSize: '16px' },
            text:   'Rotary Speed RPM'
        },
        type: 'linear',
    },
}

export function getHighchartsOptions({ series, yAxis }) {
    return {
        ...defaultHighchartsOptions,
        title: { text: '' },
        series,
        yAxis
    }
}