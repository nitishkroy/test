import { makeStyles } from '@material-ui/core'

export const useStyles = makeStyles(theme => ({
    appContainer: {
        display: 'flex',
        flexDirection: 'column',
        padding: '1rem'
    },
    headerGridItem: {
        alignItems: 'center',
        // backgroundColor: 'green',
        display: 'flex',
        flexDirection: 'row',
        padding: '1rem'
    },
    headerLogo: {
        objectFit: 'contain',
        maxWidth: '6.125rem',
        width: '6.125rem'
    },
    headerSplit: {
        width: '1px',
        height: '1rem',
        backgroundColor: '#616161',
        margin: '0 1.25rem',
    },
    headerContent: {
        alignItems: 'center',
        // border: '1px solid yellow',
        display: 'flex',
        justifyContent: 'space-between',
        width: '100%'
    },
    mainContainer: {
        
    },
    checkboxSelector: {
        display: 'flex',
        flexDirection: 'column'
    },
    overallBoxGrid: {
        display: 'flex',
        margin: '1rem 0',
        width: '100%'
    },
    boxesGrid: {
        display: 'grid',
        gap: '1rem',
        gridAutoFlow:'dense',
        gridAutoRows: '14rem',
        gridTemplateColumns: 'repeat(auto-fit, minmax(20rem, 1fr))',
        justifyContent: 'center',
        width: '100%'
    },
    historicalBoxGrid: {
        display: 'flex',
        margin: '1rem 0',
        width: '100%'
    },
    overallGridItem: {
        backgroundColor: '#272727',
        padding: '1rem',
        width: '100%'
    },
    historicalGridItem: {
        backgroundColor: '#272727',
        padding: '1rem',
        width: '100%'
    },
    gridItem: {
        backgroundColor: '#272727',
        padding: '1rem'
    },
    doubleGridItem: {
        backgroundColor: '#272727',
        gridColumn: 'span 2',
        padding: '1rem'
    },
    accordion: {
        padding: '2rem 0'
    },
    accordionDetails: {
        padding: '1rem'
    }
}))