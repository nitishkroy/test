import React, { useMemo } from 'react'
import Highcharts from 'highcharts'
import HighchartsReact from 'highcharts-react-official'
import { map } from 'lodash'

import { getHighchartsOptions } from './options'
import { SERIES, TOP_DRIVE_FACTOR, ROPA_COLORS } from '../../constants'

export default function Chart({ wits_data, top_drive, minmax_rop_mean }) {
    console.log('wits_data',wits_data)
    console.log('minmax_rop_mean', minmax_rop_mean)
    return useMemo(() => {
        const series = map(SERIES, (field, key) => {
            return {
                color: field.color,
                data: getSeriesData(key, wits_data, top_drive, minmax_rop_mean),
                id: key,
                name: field.label,
                type: field.type,
                units: 'klbf',
                yAxis: key
            }
        })

        const yAxis = map(SERIES, (field, key) => {
            return {
                id: key,
                title: { 
                    style: { color: '#9E9E9E', fontSize: '16px' },
                    text:   key === 'power_100' 
                            ? 'Torque (Surface, klbf.ft)' 
                            : key === 'wits'
                            ? 'ROPA ft/h'
                            : ''
                },
                labels: {
                    enabled: key === 'power_100' || key === 'wits'
                },
                opposite: key === 'wits',
            }
        })

        console.log('series', series)

        const options = getHighchartsOptions({ series, yAxis })
        
        return (
            <>
                <HighchartsReact
                    containerProps={{ style: { width: '100%', height: '100%' } }}
                    highcharts={Highcharts}
                    immutable
                    options={options}
                />
            </>
        )
    }, [wits_data, top_drive, minmax_rop_mean])
}

function getSeriesData(key, data, top_drive, minmax_rop_mean){
    switch(key){
        case 'top_drive_torque':
            return SERIES[key].data.map(item => {
                const torque = top_drive.power * TOP_DRIVE_FACTOR / item
                return [item, torque < top_drive.torque ? torque : top_drive.torque]
            })
        case 'wits':
            const diff_maxmin_rop_mean = minmax_rop_mean[1] - minmax_rop_mean[0]

            return data.map(row => {
                const rop_porcentage = (row.data.rop_mean - minmax_rop_mean[0]) * 100 / diff_maxmin_rop_mean
                return {
                    x: row.data.rotary_rpm_mean, 
                    y: row.data.rotary_torque_mean,
                    color:  rop_porcentage <= 20
                            ? ROPA_COLORS[4]
                            : rop_porcentage > 20 && rop_porcentage <= 40
                            ? ROPA_COLORS[3]
                            : rop_porcentage > 40 && rop_porcentage <= 60
                            ? ROPA_COLORS[2]
                            : rop_porcentage > 60 && rop_porcentage <= 80
                            ? ROPA_COLORS[1]
                            : ROPA_COLORS[0]
                }
            })
        default: 
            SERIES[key].data.map(item => [item[1], item[0]])
        return SERIES[key].data.map(item => [item[1], item[0]])
    }
}
