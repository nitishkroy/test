import { Component } from 'react';
import PropTypes from 'prop-types';
import { compose } from 'redux';
import ImmutablePropTypes from 'react-immutable-proptypes';
import { connect } from 'react-redux';
import { List, Map, fromJS, noop } from 'immutable';
import { Link, withRouter } from 'react-router';
import classNames from 'classnames';
import { some, isEqual } from 'lodash';

import Typography from '@material-ui/core/Typography';
import ActionCheckCircleIcon from '@material-ui/icons/CheckCircle';
import AlertWarningIcon from '@material-ui/icons/Warning';
import DeviceAccessTimeIcon from '@material-ui/icons/AccessTime';
import HardwareDeveloperBoardIcon from '@material-ui/icons/DeveloperBoard';
import OpacityIcon from '@material-ui/icons/Opacity';
import TrendingDownIcon from '@material-ui/icons/TrendingDown';
import VisibilityOffIcon from '@material-ui/icons/VisibilityOff';
import NoteIcon from '@material-ui/icons/SmsFailed';
import GpsIcon from '@material-ui/icons/GpsOff';

import * as convert from '@corva/ui/utils';
import { withPermissionsHOC, PERMISSIONS } from '@corva/ui/permissions';
import { showTooltip, hideTooltip } from '~/actions/tooltips';

import * as api from '~/clients/api';
import { getHiddenAlerts } from '~/clients/clientStorage';

import { getSubData } from '~/selectors/subscriptions';
import utils from '~/utils';

import {
  ACTIVITY_COLORS,
  ASSET_STATUS_COLORS,
  DEFAULT_SETTINGS,
  STATE_CATEGORY_MAP,
  OPERATIONAL_NOTE_STATUS_COLORS,
  REQUIRED_CHANNELS,
  DRILLING_ACTIVITY,
  VALUES,
} from './constants';
import { METADATA, SUBSCRIPTIONS } from './meta';
import AssetStatusClosedAlerts from './AssetStatusClosedAlerts';
import AssetStatusOpenAlerts from './AssetStatusOpenAlerts';

import './AssetStatusApp.css';

const styles = {
  alertIcon: {
    fontSize: '1.5rem',
    display: 'block',
    marginBottom: 10,
    color: 'white',
  },
  noteIcon: {
    fill: 'white',
    marginRight: 5,
    height: 24,
    width: 24,
  },
  statusColor: color => ({ backgroundColor: color }),
};

class AssetStatusApp extends Component {
  constructor(props) {
    super(props);

    const witsData = getSubData(props.data, SUBSCRIPTIONS[0]); // wits subscription
    const sensors = this.getPatchedSensorStatuses(witsData);
    const dataDelay = this.getDataDelay(witsData, props.time);
    const isDataModeratelyDelayed = this.getIsDataDelayed(
      witsData,
      dataDelay,
      this.props.asset,
      this.props.moderateDataDelay
    );
    const isDataSeverelyDelayed = this.getIsDataDelayed(
      witsData,
      dataDelay,
      this.props.asset,
      this.props.severeDataDelay
    );
    const isInitialSummaryFull = props.appContext.get('view') === 'report';
    const hiddenAlerts = getHiddenAlerts(props.appId, []);

    this.state = {
      operationSummaries: getSubData(
        props.data,
        SUBSCRIPTIONS[1], // new summaries subscription
        false
      ),
      alerts: List(),
      activitySummaryData: List(),
      sensors,
      dataDelay,
      isDataModeratelyDelayed,
      isDataSeverelyDelayed,
      isMudDelayed: false,
      isSurveyDelayed: false,
      isDrillstringUncalibrated: false,
      showFullPrev24HoursSummary: isInitialSummaryFull,
      showFullNext24HoursSummary: isInitialSummaryFull,
      drillstringConfigData: Map(),
      mudConfigData: Map(),
      casingConfigData: Map(),
      actualSurveyConfigData: Map(),
      enableScrolling: false,
      hiddenAlerts: List(hiddenAlerts),
    };

    // NOTE: loadingActivitySummaryData is not in the state because it doesn't
    // affect the render
    this.loadingActivitySummaryData = false;
    this.summaryAndConfigsTimer = null;
    this.alertsTimer = null;
    this.delayTimer = null;
    this.enableScrollTimer = null;
    this.lastCheckHoleDepth = witsData.getIn(['data', 'hole_depth']);
  }

  UNSAFE_componentWillMount() {
    const witsData = getSubData(this.props.data, SUBSCRIPTIONS[0]);

    this.loadAlerts(this.props.time);
    this.loadConfigs(witsData);

    if (this.props.showActivitySummary) {
      this.loadActivitySummaryData(this.props.asset, witsData);
    }
  }

  componentDidMount() {
    this.delayTimer = setInterval(this.updateDelay, VALUES.TWO_SECONDS);
    this.summaryAndConfigsTimer = setInterval(this.updateSummaryAndConfigsData, VALUES.TEN_MINUTES);
    this.alertsTimer = setInterval(this.updateAlerts, VALUES.THIRTY_SECONDS);
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    const nextWitsData = getSubData(nextProps.data, SUBSCRIPTIONS[0]);
    const currentWitsData = getSubData(this.props.data, SUBSCRIPTIONS[0]);

    const nextOperationSummaries = getSubData(
      nextProps.data,
      SUBSCRIPTIONS[1], // new summaries subscription
      false
    );
    const currentOperationSummaries = getSubData(this.props.data, SUBSCRIPTIONS[1], false);

    const nextUpdatedOperationSummary = getSubData(
      nextProps.data,
      SUBSCRIPTIONS[2] // updated summaries subscription
    );
    const currentUpdatedOperationSummary = getSubData(this.props.data, SUBSCRIPTIONS[2]);

    // NOTE: Replace op summaries if there is new one or find updated one and update it
    // in the state.
    if (!nextOperationSummaries.equals(currentOperationSummaries)) {
      this.setState({ operationSummaries: nextOperationSummaries });
    } else if (
      nextUpdatedOperationSummary &&
      !nextUpdatedOperationSummary.equals(currentUpdatedOperationSummary)
    ) {
      this.setState(({ operationSummaries }) => {
        const updatedSummaryId = nextUpdatedOperationSummary.get('_id');
        const updatedSummaryIndex = operationSummaries.findIndex(
          summary => summary.get('_id') === updatedSummaryId
        );
        return {
          operationSummaries: operationSummaries.set(
            updatedSummaryIndex,
            nextUpdatedOperationSummary
          ),
        };
      });
    }

    // NOTE: Load activity summary immediately only if showActivitySummary
    // has been changed and it is turned on now
    if (
      nextProps.showActivitySummary !== this.props.showActivitySummary &&
      nextProps.showActivitySummary &&
      !this.loadingActivitySummaryData
    ) {
      this.loadActivitySummaryData(nextProps.asset, nextWitsData);
    }

    if (nextProps.time !== this.props.time) {
      this.loadAlerts(nextProps.time);
    }

    if (!nextWitsData.equals(currentWitsData)) {
      this.setState({ sensors: this.getPatchedSensorStatuses(nextWitsData) });
      const isDrillstringUncalibrated = this.getIsDrillStringUncalibrated(
        nextWitsData,
        this.state.drillstringConfigData,
        this.state.casingConfigData
      );
      this.setState({ isDrillstringUncalibrated });

      const mudChanged =
        nextWitsData.getIn(['metadata', 'mud']) !== currentWitsData.getIn(['metadata', 'mud']);
      const drillstringChanged =
        nextWitsData.getIn(['metadata', 'drillstring']) !==
        currentWitsData.getIn(['metadata', 'drillstring']);
      const casingChanged =
        nextWitsData.getIn(['metadata', 'casing']) !==
        currentWitsData.getIn(['metadata', 'casing']);
      const surveyChanged =
        nextWitsData.getIn(['metadata', 'actual_survey']) !==
        currentWitsData.getIn(['metadata', 'actual_survey']);

      const holeDepth = nextWitsData.getIn(['data', 'hole_depth']);
      const substantialChange = Math.abs(holeDepth - this.lastCheckHoleDepth) > 30;

      if (mudChanged || drillstringChanged || casingChanged || surveyChanged || substantialChange) {
        this.loadConfigs(nextWitsData);
      }
    }
  }

  shouldComponentUpdate(nextProps, nextState) {
    const currentWitsData = getSubData(this.props.data, SUBSCRIPTIONS[0]);
    const nextWitsData = getSubData(nextProps.data, SUBSCRIPTIONS[0]);
    return (
      nextState.dataDelay !== this.state.dataDelay ||
      nextState.enableScrolling !== this.state.enableScrolling ||
      !nextWitsData.equals(currentWitsData) ||
      nextState.mudConfigData !== this.state.mudConfigData ||
      nextState.drillstringConfigData !== this.state.drillstringConfigData ||
      nextState.isDrillstringUncalibrated !== this.state.isDrillstringUncalibrated ||
      nextState.actualSurveyConfigData !== this.state.actualSurveyConfigData ||
      nextState.casingConfigData !== this.state.casingConfigData ||
      !nextState.operationSummaries.equals(this.state.operationSummaries) ||
      !nextState.alerts.equals(this.state.alerts) ||
      nextState.isDataModeratelyDelayed !== this.state.isDataModeratelyDelayed ||
      nextState.isDataSeverelyDelayed !== this.state.isDataSeverelyDelayed ||
      nextState.showFullPrev24HoursSummary !== this.state.showFullPrev24HoursSummary ||
      nextState.showFullNext24HoursSummary !== this.state.showFullNext24HoursSummary ||
      nextState.isMudDelayed !== this.state.isMudDelayed ||
      nextState.isSurveyDelayed !== this.state.isSurveyDelayed ||
      !isEqual(nextState.sensors, this.state.sensors) ||
      !nextState.activitySummaryData.equals(this.state.activitySummaryData) ||
      nextProps.time !== this.props.time ||
      nextProps.showAssetLink !== this.props.showAssetLink ||
      nextProps.showActivitySummary !== this.props.showActivitySummary ||
      nextProps.ignoreROPWarning !== this.props.ignoreROPWarning ||
      nextProps.fontSize !== this.props.fontSize ||
      nextProps.moderateDataDelay !== this.props.moderateDataDelay ||
      nextProps.severeDataDelay !== this.props.severeDataDelay
    );
  }

  componentDidUpdate(prevProps) {
    // NOTE: If a user changes delay threshold settings we need to update the state
    // immediately, don't wait for this.updateDelay fires
    if (
      prevProps.moderateDataDelay !== this.props.moderateDataDelay ||
      prevProps.severeDataDelay !== this.props.severeDataDelay
    ) {
      this.updateDelay();
    }
  }

  componentWillUnmount() {
    clearTimeout(this.enableScrollTimer);
    clearInterval(this.delayTimer);
    clearInterval(this.summaryAndConfigsTimer);
    clearInterval(this.alertsTimer);
  }

  onEnter = () => {
    this.enableScrollTimer = setTimeout(() => this.setState({ enableScrolling: true }), 1000);
  };

  onLeave = () => {
    clearTimeout(this.enableScrollTimer);
    this.setState({ enableScrolling: false });
  };

  get firstOpenAlert() {
    return this.state.alerts.find(alert => alert.get('status') === 'open');
  }

  get showAssetLink() {
    // NOTE: Show asset link if it's not asset dashboard, it has
    // approprieate setting value turned on and there is no 'theme=report' in query params
    return !this.props.params.assetId && this.props.showAssetLink && !this.themeIsReport;
  }

  get assetOperationalNote() {
    const operationalNoteRecord = this.state.operationSummaries.find(
      record => record.getIn(['data', 'type']) === 'operational_note'
    );
    return operationalNoteRecord
      ? {
          note: operationalNoteRecord.getIn(['data', 'note']),
          status: operationalNoteRecord.getIn(['data', 'status']),
          visibleToUsers: operationalNoteRecord.getIn(['data', 'visible_to_users']),
        }
      : {};
  }

  get assetPrev24HoursSummary() {
    const prev24SummaryData = this.state.operationSummaries.find(
      record =>
        record.getIn(['data', 'type']) !== 'next24' &&
        record.getIn(['data', 'type']) !== 'operational_note'
    );
    if (prev24SummaryData) {
      const endDate = this.props.time ? new Date(this.props.time) : new Date();
      const summary = prev24SummaryData.getIn(['data', 'summary']);
      const timestamp = prev24SummaryData.getIn(['data', 'date_time']);
      const minTS = Math.round(endDate.getTime() / 1000) - VALUES.TWENTY_FOUR_HOURS;
      // NOTE: Timestamp greater than now minus 24 hours
      if (timestamp >= minTS) {
        return summary;
      }
    }

    return null;
  }

  get assetNext24HoursSummary() {
    const next24SummaryData = this.state.operationSummaries.find(
      record => record.getIn(['data', 'type']) === 'next24'
    );
    if (next24SummaryData) {
      const endDate = this.props.time ? new Date(this.props.time) : new Date();
      const summary = next24SummaryData.getIn(['data', 'summary']);
      const timestamp = next24SummaryData.getIn(['data', 'date_time']);
      const minTS = Math.round(endDate.getTime() / 1000) - VALUES.TWENTY_FOUR_HOURS;
      // NOTE: Timestamp greater than now minus 24 hours
      if (timestamp >= minTS) {
        return summary;
      }
    }

    return null;
  }

  get assetActivity() {
    const data = getSubData(this.props.data, SUBSCRIPTIONS[0]);
    const state = data.getIn(['data', 'state']);
    return STATE_CATEGORY_MAP[state] || 'Other';
  }

  get isAnySensorMissing() {
    const anyMissing = some(this.state.sensors, this.isSensorMissingFactory());
    return this.getIsAssetActive(this.props.asset) && anyMissing;
  }

  get assetStatusColor() {
    const configDelayed = this.state.isMudDelayed || this.state.isSurveyDelayed;

    if (this.isAnySensorMissing || this.state.isDataSeverelyDelayed) {
      return ASSET_STATUS_COLORS.CRITICAL;
    } else if (this.state.isDataModeratelyDelayed || configDelayed) {
      return ASSET_STATUS_COLORS.WARNING;
    } else if (this.getIsAssetActive(this.props.asset)) {
      return ASSET_STATUS_COLORS.OPTIMAL;
    }

    return ASSET_STATUS_COLORS.IDLE;
  }

  get themeIsReport() {
    return this.props.router.location.query.theme === 'report';
  }

  get filteredAlerts() {
    return this.state.alerts.filter(alert => !this.state.hiddenAlerts.contains(alert.get('id')));
  }

  getPrev24TooltipParams(summary, showFullSummary) {
    return {
      label: <div className="c-asset-status-content__tooltip">{summary}</div>,
      targetId: 'c-prev24-asset-summary__tooltip-id',
      place: 'bottom',
      disable: !summary || showFullSummary,
    };
  }

  getNoteTooltipParams(note) {
    return {
      label: <div className="c-asset-status-content__tooltip">{note}</div>,
      targetId: 'c-operational-note__tooltip-id',
      place: 'bottom',
    };
  }

  getDataDelay(witsData, time = null) {
    // NOTE: time is come from well timeline app, so if it changes subscription data
    // time range we don't calculate the delay for the last subscription data timestamp.
    if (time) return 0;

    const timestamp = witsData.getIn(['timestamp']);
    const now = Math.round(new Date().getTime() / 1000);
    return now - timestamp;
  }

  getPatchedSensorStatuses(witsData) {
    return REQUIRED_CHANNELS.map(sensor => ({
      ...sensor,
      status: this.isSensorPresent(witsData, sensor.name),
    }));
  }

  // NOTE: Do not show message if alert is older than 30 days for historical wells
  getIsDataDelayed(witsData, delay, asset, delayThreshold) {
    const dataDelay = 60 * delayThreshold;
    const isAssetActive = this.getIsAssetActive(asset);
    const isLiveWell = this.getIsLiveWell(witsData);
    return isAssetActive && delay > dataDelay && isLiveWell && delay < VALUES.THIRTY_DAYS;
  }

  getIsDrillStringUncalibrated(witsData, drillstring, casing) {
    if (drillstring.isEmpty() || !casing.isEmpty()) {
      return false;
    }

    const bitDepth = witsData.getIn(['data', 'bit_depth']);
    const holeDepth = witsData.getIn(['data', 'hole_depth']);
    const calibrated = drillstring.getIn(['data', 'calibrated'], false);

    // NOTE: Do not flag uncalibration if the bit is not on bottom.
    // Only show for admin users
    return !calibrated && bitDepth >= holeDepth - 100 && this.props.canViewCorvaAssetStatus;
  }

  getDrillStringText(drillstring) {
    const drillstringId = drillstring.getIn(['data', 'id']);
    const components = drillstring.getIn(['data', 'components']);

    if (components.isEmpty()) return `BHA #${drillstringId}`;

    const bitSize = parseFloat(components.last().get('size'));
    const convertedBitSize = convert.convertValue(bitSize, 'shortLength', 'in');
    return `BHA #${drillstringId} / ${utils.formatValuePrecision(convertedBitSize)}`;
  }

  getCasingText(casing) {
    const casingOd = casing.getIn(['data', 'outer_diameter']);
    const convertedCasingOd = convert.convertValue(casingOd, 'shortLength', 'in');
    return `Casing ${utils.formatValuePrecision(convertedCasingOd)}`;
  }

  getMudText(mud) {
    const mudDensity = mud.getIn(['data', 'mud_density']);
    const convertedMudDensity = convert.convertValue(mudDensity, 'density', 'ppg');
    return `Fluid ${utils.formatValuePrecision(convertedMudDensity)}`;
  }

  getSurveyText(surveys, holeDepth) {
    const stations = surveys.getIn(['data', 'stations']);

    if (!stations || stations.isEmpty()) return '';

    // Get the last survey record under the current hole depth.
    const lastStation = stations
      .reverse()
      .find(record => parseFloat(record.get('measured_depth')) <= parseFloat(holeDepth));
    const lastStationDepth = lastStation ? lastStation.get('measured_depth') : 0;
    return `Survey @ ${utils.formatValuePrecision(
      convert.convertValue(lastStationDepth, 'length', 'ft')
    )}`;
  }

  getIsMudDelayed(witsData, mud) {
    const timestamp = witsData.getIn(['timestamp']);
    const holeDepth = witsData.getIn(['data', 'hole_depth']);
    const mudRecordDepth = mud.getIn(['data', 'depth']);
    const mudRecordTimestamp = mud.getIn(['data', 'date']);

    return (
      timestamp - mudRecordTimestamp > VALUES.TWO_DAYS &&
      holeDepth - VALUES.FEW_DAYS_DRILLING_DISTANCE > mudRecordDepth &&
      this.props.canViewCorvaAssetStatus
    );
  }

  getIsSurveyDelayed(witsData, surveys) {
    const holeDepth = witsData.getIn(['data', 'hole_depth']);
    const stations = surveys.getIn(['data', 'stations']);

    if (stations && stations.isEmpty() && holeDepth > VALUES.MINIMUM_HOLE_DEPTH) {
      return true;
    }

    const lastStationDepth = stations && stations.last() && stations.last().get('measured_depth');
    return (
      holeDepth - VALUES.TWO_AND_HALF_COMPLETE_DRILLING_STANDS > lastStationDepth &&
      this.props.canViewCorvaAssetStatus
    );
  }

  getIsAssetActive(asset) {
    return asset.get('status') === 'active';
  }

  getIsLiveWell(data) {
    // NOTE: The app field is the source app key of streams
    // corva.witsml-source: the source app key used by stream connector
    // corva.source: the source app key used when creating a stream by `from witsml` wizard
    return ['corva.source', 'corva.witsml-source'].includes(data.get('app'));
  }

  setHiddenAlerts = hiddenAlerts => this.setState({ hiddenAlerts: List(hiddenAlerts) });

  isSensorMissingFactory() {
    // NOTE: Ignore ROP channel warning when off-bottom
    const data = getSubData(this.props.data, SUBSCRIPTIONS[0]).get('data');
    const holeDepth = data.get('hole_depth');
    const bitDepth = data.get('bit_depth');
    const { ignoreROPWarning } = this.props;
    return ({ name, status }) =>
      this.props.canViewCorvaAssetStatus &&
      (name === 'rop' && ignoreROPWarning && holeDepth !== bitDepth ? false : !status);
  }

  isSensorPresent(data, name) {
    return data.getIn(['data', name]) !== null;
  }

  isDrillingActivity(activity) {
    return DRILLING_ACTIVITY.has(activity);
  }

  handleShowPrev24HoursSummary = () =>
    this.setState(({ showFullPrev24HoursSummary }) => ({
      showFullPrev24HoursSummary: !showFullPrev24HoursSummary,
    }));

  handleShowNext24HoursSummary = () =>
    this.setState(({ showFullNext24HoursSummary }) => ({
      showFullNext24HoursSummary: !showFullNext24HoursSummary,
    }));

  updateDelay = () => {
    const witsData = getSubData(this.props.data, SUBSCRIPTIONS[0]);
    const dataDelay = this.getDataDelay(witsData, this.props.time);
    const isDataModeratelyDelayed = this.getIsDataDelayed(
      witsData,
      dataDelay,
      this.props.asset,
      this.props.moderateDataDelay
    );
    const isDataSeverelyDelayed = this.getIsDataDelayed(
      witsData,
      dataDelay,
      this.props.asset,
      this.props.severeDataDelay
    );

    this.setState({
      dataDelay,
      isDataModeratelyDelayed,
      isDataSeverelyDelayed,
    });
  };

  updateSummaryAndConfigsData = () => {
    const witsData = getSubData(this.props.data, SUBSCRIPTIONS[0]);
    if (this.props.showActivitySummary && !this.loadingActivitySummaryData) {
      this.loadActivitySummaryData(this.props.asset, witsData);
    }
    if (this.state.isDrillstringDataUncalibrated) {
      this.loadConfigs(witsData);
    }
  };

  async loadActivitySummaryData(asset, witsData) {
    this.loadingActivitySummaryData = true;

    const endTS = witsData.get('timestamp');
    const startTS = endTS - VALUES.TWELVE_HOURS; // NOTE: 12 hours before end

    const params = fromJS({
      asset_id: asset.get('id'),
      query: `{timestamp#gte#${Math.round(startTS)}}AND{timestamp#lte#${Math.round(endTS)}}`,
      limit: 1000,
      fields: ['timestamp', 'data.state'].join(','),
    });

    let activitySummaryData;
    try {
      activitySummaryData = await api.getAppStorage(
        METADATA.recordProvider,
        METADATA.recordCollections.summary1m,
        asset.get('id'),
        params
      );
    } catch (e) {
      this.loadingActivitySummaryData = false;
      return;
    }

    this.loadingActivitySummaryData = false;
    this.setState({ activitySummaryData });
  }

  updateAlerts = () => {
    // NOTE: If a user selected a specific time through well timeline app, we don't want
    // to reload alerts.
    if (!this.props.time) {
      this.loadAlerts();
    }
  };

  async loadAlerts(time) {
    const end = time ? new Date(time).getTime() : new Date().getTime();
    const start = end - VALUES.TWENTY_FOUR_HOURS * 1000;
    const assetId = this.props.asset.get('id');
    const assetParentId = this.props.asset.get('parent_asset_id');

    let alerts;
    try {
      alerts = await api.getAlerts({
        end,
        start,
        per_page: 100,
        rigs: assetParentId,
      });
    } catch (e) {
      return;
    }

    // TODO: Enable filtering by asset id on the backend side
    this.setState({ alerts: alerts.filter(alert => alert.getIn(['asset', 'id']) === assetId) });
  }

  loadConfigs(witsData) {
    const metadata = witsData.get('metadata');
    const drillstringRecordId = metadata && metadata.get('drillstring');
    const mudRecordId = metadata && metadata.get('mud');
    const casingRecordId = metadata && metadata.get('casing');
    const actualSurveyRecordId = metadata && metadata.get('actual_survey');

    this.lastCheckHoleDepth = witsData.getIn(['data', 'hole_depth']);

    Promise.all([
      drillstringRecordId &&
        api.getAppStorageRecord(
          METADATA.recordProvider,
          METADATA.recordCollections.drillstring,
          drillstringRecordId
        ),
      casingRecordId &&
        api.getAppStorageRecord(
          METADATA.recordProvider,
          METADATA.recordCollections.casing,
          casingRecordId
        ),
    ])
      .then(records => this.handleDrillstringAndCasingRecords(...records, witsData))
      .catch(noop);

    if (mudRecordId) {
      api
        .getAppStorageRecord(METADATA.recordProvider, METADATA.recordCollections.mud, mudRecordId)
        .then(record => this.handleMudRecord(record, witsData))
        .catch(noop);
    }

    if (actualSurveyRecordId) {
      api
        .getAppStorageRecord(
          METADATA.recordProvider,
          METADATA.recordCollections.actualSurvey,
          actualSurveyRecordId
        )
        .then(record => this.handleActualSurveyRecord(record, witsData))
        .catch(noop);
    }
  }

  handleDrillstringAndCasingRecords = (drillstringRecord, casingRecord, witsData) => {
    const drillstringConfigData = drillstringRecord || Map();
    const casingConfigData = casingRecord || Map();

    this.setState({
      casingConfigData,
      drillstringConfigData,
      isDrillstringUncalibrated: this.getIsDrillStringUncalibrated(
        witsData,
        drillstringConfigData,
        casingConfigData
      ),
    });
  };

  handleMudRecord = (record, witsData) => {
    const mudConfigData = record || Map();

    this.setState({
      mudConfigData,
      isMudDelayed: this.getIsMudDelayed(witsData, mudConfigData),
    });
  };

  handleActualSurveyRecord = (record, witsData) => {
    const actualSurveyConfigData = record || Map();

    this.setState({
      actualSurveyConfigData,
      isSurveyDelayed: this.getIsSurveyDelayed(witsData, actualSurveyConfigData),
    });
  };

  renderAssetStatusBar() {
    const { isAnySensorMissing } = this;
    const openAlert = this.firstOpenAlert;
    const isDataDelayed = this.state.isDataModeratelyDelayed;
    const isMudDataDelayed = this.state.isMudDelayed;
    const isSurveyDataDelayed = this.state.isSurveyDelayed;
    const isDrillstringDataUncalibrated = this.state.isDrillstringUncalibrated;

    const isOptimal =
      !openAlert &&
      !isAnySensorMissing &&
      !isDataDelayed &&
      !isMudDataDelayed &&
      !isSurveyDataDelayed;

    return (
      <div className="c-asset-status-bar" style={styles.statusColor(this.assetStatusColor)}>
        <div className="c-asset-status-bar-icons">
          {openAlert && <AlertWarningIcon style={styles.alertIcon} />}
          {isOptimal && <ActionCheckCircleIcon style={styles.alertIcon} />}
          {!openAlert && isAnySensorMissing && (
            <HardwareDeveloperBoardIcon style={styles.alertIcon} />
          )}
          {isDataDelayed && <DeviceAccessTimeIcon style={styles.alertIcon} />}
          {isMudDataDelayed && <OpacityIcon style={styles.alertIcon} />}
          {isSurveyDataDelayed && <TrendingDownIcon style={styles.alertIcon} />}
          {isDrillstringDataUncalibrated && <GpsIcon style={styles.alertIcon} />}
        </div>
      </div>
    );
  }

  renderAssetDepths() {
    const data = getSubData(this.props.data, SUBSCRIPTIONS[0]).get('data');
    const bitDepth = convert.convertValue(data.get('bit_depth'), 'length', 'ft');
    const holeDepth = convert.convertValue(data.get('hole_depth'), 'length', 'ft');
    return (
      <div className="c-asset-status-content__depths">
        <Typography
          variant="body2"
          className={classNames({
            'c-asset-status-content__depths__content': true,
            'c-asset-status-content__depths__content-normal': !this.props.fontSize,
            'c-asset-status-content__depths__content-large': !!this.props.fontSize,
          })}
        >
          <span>{utils.formatValuePrecision(bitDepth)}</span>/
          <span>{utils.formatValuePrecision(holeDepth)}</span>
          {convert.getUnitDisplay('length')}
        </Typography>
      </div>
    );
  }

  renderAssetConfigs() {
    const holeDepth = getSubData(this.props.data, SUBSCRIPTIONS[0]).getIn(['data', 'hole_depth']);
    const drillstring = this.state.drillstringConfigData;
    const casing = this.state.casingConfigData;
    const mud = this.state.mudConfigData;
    const actualSurvey = this.state.actualSurveyConfigData;

    return (
      (!drillstring.isEmpty() || !casing.isEmpty()) &&
      !mud.isEmpty() && (
        <Typography variant="body2" className="c-asset-status-content__config">
          <span>
            {casing.isEmpty() ? this.getDrillStringText(drillstring) : this.getCasingText(casing)}
          </span>
          &nbsp;
          <span className="c-asset-status-content__config_unit">
            {convert.getUnitDisplay('shortLength')}
          </span>
          {this.state.isDrillstringUncalibrated && (
            <span className="c-asset-status-content__config_uncalibrated">Uncalibrated</span>
          )}
          &nbsp;&nbsp;•&nbsp;&nbsp;
          <span>{this.getMudText(mud)}</span>
          &nbsp;
          <span className="c-asset-status-content__config_unit">
            {convert.getUnitDisplay('density')}
          </span>
          &nbsp;&nbsp;•&nbsp;&nbsp;
          <span>{this.getSurveyText(actualSurvey, holeDepth)}</span>
          &nbsp;
          <span className="c-asset-status-content__config_unit">
            {convert.getUnitDisplay('length')}
          </span>
        </Typography>
      )
    );
  }

  renderAssetCurrentActivity() {
    const activity = this.assetActivity;
    const isDrillingActivity = this.isDrillingActivity(activity);
    return (
      <Typography
        variant="body2"
        className="c-asset-status-content__current-activity"
        component="div"
      >
        <div
          className={classNames({
            'c-asset-status-content__current-activity__content-normal': !this.props.fontSize,
            'c-asset-status-content__current-activity__content-large': !!this.props.fontSize,
            'activity-drilling': isDrillingActivity,
            'activity-other': !isDrillingActivity,
          })}
        >
          {activity}
        </div>
      </Typography>
    );
  }

  renderActivitySummary = () => (
    <div className="c-asset-status-content__general-activity">
      <div className="c-asset-status__activity-container">
        <div className="c-asset-status__activity">
          {this.state.activitySummaryData.reverse().map((point, idx) => (
            <Typography
              variant="body2"
              key={idx} // eslint-disable-line react/no-array-index-key
              className="c-asset-status__activity-tick"
              style={{
                backgroundColor:
                  ACTIVITY_COLORS[STATE_CATEGORY_MAP[point.getIn(['data', 'state'])] || 'Other'],
              }}
              title={STATE_CATEGORY_MAP[point.getIn(['data', 'state'])] || 'Other'}
            />
          ))}
        </div>
        <Typography
          variant="body2"
          component="div"
          className={classNames({
            'c-asset-status__activity-time': true,
            'c-asset-status__activity-label-normal': !this.props.fontSize,
            'c-asset-status__activity-label-large': !!this.props.fontSize,
          })}
        >
          <div className="c-asset-status__activity-start">12 Hours Ago</div>
          <div className="c-asset-status__activity-end">Now</div>
        </Typography>
      </div>
    </div>
  );

  renderAssetSummary = (summary, showFullSummary, showFullSummaryHandler) => {
    const tooltipParams = this.getPrev24TooltipParams(summary, showFullSummary);

    return (
      <div>
        <div
          className="c-asset-status-content__summary"
          data-tip
          data-for={tooltipParams.targetId}
          onMouseEnter={() => this.props.showTooltip(tooltipParams)}
          onMouseLeave={this.props.hideTooltip}
          onClick={showFullSummaryHandler}
          style={{
            whiteSpace: showFullSummary ? 'normal' : 'nowrap',
            cursor: summary ? 'pointer' : 'initial',
          }}
        >
          {summary || '-'}
        </div>
      </div>
    );
  };

  renderOperationalNote() {
    const { status, note, visibleToUsers } = this.assetOperationalNote;
    const color = OPERATIONAL_NOTE_STATUS_COLORS[status];
    const showNote = note && (this.props.canViewCorvaAssetStatus || visibleToUsers);

    const tooltipParams = this.getNoteTooltipParams(note);

    return (
      showNote && (
        <div className="c-asset-status-content__operational-note" style={styles.statusColor(color)}>
          <NoteIcon style={styles.noteIcon} />
          <div className="note-border" />
          {!visibleToUsers && <VisibilityOffIcon style={styles.noteIcon} />}
          <div
            className="c-asset-status-content__operational-note__note"
            data-tip
            data-for={tooltipParams.targetId}
            onMouseEnter={() => this.props.showTooltip(tooltipParams)}
            onMouseLeave={this.props.hideTooltip}
          >
            {note}
          </div>
        </div>
      )
    );
  }

  renderPrev24HoursSummary = () => (
    <div>
      <Typography
        variant="body2"
        className={classNames({
          'c-asset-status-content__when': true,
          'c-asset-status-content__when-normal': !this.props.fontSize,
          'c-asset-status-content__when-large': !!this.props.fontSize,
        })}
      >
        Previous 24 Hours
      </Typography>
      {this.renderAssetSummary(
        this.assetPrev24HoursSummary,
        this.state.showFullPrev24HoursSummary,
        this.handleShowPrev24HoursSummary
      )}
    </div>
  );

  renderNext24HoursSummary = () => (
    <div>
      <Typography
        variant="body2"
        className={classNames({
          'c-asset-status-content__when': true,
          'c-asset-status-content__when-normal': !this.props.fontSize,
          'c-asset-status-content__when-large': !!this.props.fontSize,
        })}
      >
        Next 24 Hours
      </Typography>
      {this.renderAssetSummary(
        this.assetNext24HoursSummary,
        this.state.showFullNext24HoursSummary,
        this.handleShowNext24HoursSummary,
        { id: `next24_asset_summary_${this.props.appId}`, place: 'top' }
      )}
    </div>
  );

  renderMissingSensors = () => (
    <div className="c-asset-status-sensors">
      <div>
        <span>Currently missing required sensors in the data stream: </span>
        {this.state.sensors
          .filter(item => !item.status)
          .map((item, index, array) => (
            <span key={item.name}>
              {item.title}
              {index < array.length - 1 ? ', ' : '.'}
            </span>
          ))}
      </div>
    </div>
  );

  renderDataDelay = () => (
    <div className="c-asset-status-delays">
      <div>
        <span>WITSML server transmit delay: </span>
        <span>{(this.state.dataDelay / 60).formatNumeral('0')} minutes</span>
      </div>
    </div>
  );

  renderMudDelay = () => (
    <div className="c-asset-status-config-delays">
      <div>
        <span>The last fluid record is out of date.</span>
      </div>
    </div>
  );

  renderSurveyDelay = () => (
    <div className="c-asset-status-config-delays">
      <div>
        <span>The last survey station is out of date.</span>
      </div>
    </div>
  );

  render = () => (
    <div className="c-asset-status">
      <div className="c-asset-status-container">
        {this.showAssetLink && (
          <Link
            to={`/assets/${this.props.asset.get('id')}/`}
            className="c-asset-status__asset-link"
          >
            View Asset &gt;
          </Link>
        )}
        {this.renderAssetStatusBar()}
        <div
          className={classNames({
            'c-asset-status-content': true,
            'c-asset-status-content--scrollable': this.state.enableScrolling,
            'c-asset-status-content--not-scrollable': !this.state.enableScrolling,
          })}
          onMouseEnter={this.onEnter}
          onMouseLeave={this.onLeave}
        >
          <Typography
            classes={{ root: 'c-asset-status-content__title' }}
            variant={!this.props.fontSize ? 'h5' : 'h4'}
          >
            {this.props.asset.get('parent_asset_name')}
          </Typography>
          <Typography
            className="c-asset-status-content__subtitle"
            variant={!this.props.fontSize ? 'body1' : 'h6'}
          >
            {this.props.asset.get('name')}
            {this.props.canViewCorvaAssetStatus && (
              <span
                className="c-asset-status-content__company-name"
                variant={!this.props.fontSize ? 'body2' : 'h6'}
              >
                {this.props.asset.get('company_name')}
              </span>
            )}
          </Typography>
          {this.props.renderLastAnnotation && this.props.renderLastAnnotation()}
          <AssetStatusOpenAlerts
            alerts={this.filteredAlerts}
            appId={this.props.appId}
            setHiddenAlerts={this.setHiddenAlerts}
          />
          {this.renderAssetDepths()}
          {this.renderAssetConfigs()}
          {this.renderAssetCurrentActivity()}
          {this.props.showActivitySummary &&
            !this.state.activitySummaryData.isEmpty() &&
            this.renderActivitySummary()}
          {this.renderOperationalNote()}
          {this.renderPrev24HoursSummary()}
          <AssetStatusClosedAlerts
            alerts={this.filteredAlerts}
            appId={this.props.appId}
            setHiddenAlerts={this.setHiddenAlerts}
          />
          {this.renderNext24HoursSummary()}
          {this.isAnySensorMissing && this.renderMissingSensors()}
          {this.getIsAssetActive(this.props.asset) &&
            this.state.isDataModeratelyDelayed &&
            this.renderDataDelay()}
          {this.getIsAssetActive(this.props.asset) &&
            this.state.isMudDelayed &&
            this.renderMudDelay()}
          {this.getIsAssetActive(this.props.asset) &&
            this.state.isSurveyDelayed &&
            this.renderSurveyDelay()}
        </div>
      </div>
    </div>
  );
}

AssetStatusApp.propTypes = {
  appId: PropTypes.number.isRequired,
  asset: ImmutablePropTypes.map.isRequired,
  data: ImmutablePropTypes.map.isRequired,
  time: PropTypes.string,
  canViewCorvaAssetStatus: PropTypes.bool.isRequired,
  // NOTE: Settings
  showActivitySummary: PropTypes.bool,
  showAssetLink: PropTypes.bool,
  ignoreROPWarning: PropTypes.bool,
  moderateDataDelay: PropTypes.number,
  severeDataDelay: PropTypes.number,
  fontSize: PropTypes.number,

  showTooltip: PropTypes.func.isRequired,
  hideTooltip: PropTypes.func.isRequired,
  appContext: ImmutablePropTypes.mapContains({
    view: PropTypes.string.isRequired,
  }).isRequired,
  renderLastAnnotation: PropTypes.func,
};

AssetStatusApp.defaultProps = {
  time: null,
  ...DEFAULT_SETTINGS,

  renderLastAnnotation: () => undefined,
};

export default compose(
  withRouter,
  withPermissionsHOC({ canViewCorvaAssetStatus: PERMISSIONS.canViewCorvaAssetStatus }),
  connect(null, {
    showTooltip,
    hideTooltip,
  })
)(AssetStatusApp);