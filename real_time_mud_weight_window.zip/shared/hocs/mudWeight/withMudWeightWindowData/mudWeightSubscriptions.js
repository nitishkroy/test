export const mudWeightSubscriptions = [
    {
      provider: 'corva',
      collection: 'data.pressure-gradient',
      meta: { subscribeToLatestOnly: true, allowEmpty: true },
      params: {
        limit: 1,
        sort: '{ timestamp: -1 }',
      },
    },
    {
      provider: 'corva',
      collection: 'hydraulics.pressure-loss',
      params: {
        fields: [
          'timestamp',
          'data.ecds',
          'data.casing_depth',
          'data.alerts',
          'data.mud_density',
          'data.flowrate',
          'data.predicted_ecd_at_bit',
          'data.standpipe_pressure',
          'data.mwd_annulus_ecd',
          'data.rop',
          'data.predicted_annulus_total_pressure_at_bit',
          'data.bit_depth',
        ].join(','),
      },
    },
    {
      provider: 'corva',
      collection: 'wits',
    },
    {
      provider: 'corva',
      collection: 'data.mud.plan',
      meta: { subscribeToLatestOnly: true, allowEmpty: true },
      params: {
        limit: 1,
        sort: '{ timestamp: -1 }',
      },
    },
  ];
  
  export const mudWeightMetadata = {
    provider: 'corva',
    recordCollections: {
      pressureLoss: 'hydraulics.pressure-loss',
      formations: 'data.formations',
    },
  };