import Loadable from 'react-loadable';
import { asyncAppLoadableOptions } from '~/utils/loadable';

import settings from './settings';
import * as constants from './constants';

const mwWindowApp = Loadable(
  asyncAppLoadableOptions({
    loader: () => import(/* webpackChunkName: "app/wellboreStability-mwWindow/" */ './mwWindowApp'),
  })
);

export default {
  AppComponent: mwWindowApp,
  settings,
  constants,
};