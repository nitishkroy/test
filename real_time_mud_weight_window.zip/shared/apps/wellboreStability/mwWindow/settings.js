import { Map, List } from 'immutable';

import { chartColorsEditorForDefinitions } from 'components/ChartColorsEditor';
import { radioEditorForDefinitions } from 'components/RadioEditor';
import { textEditorForDefinitions } from 'components/TextEditor';
import { switchEditorForDefinitions } from 'components/SwitchEditor';

import { ORIENTATION_SETTINGS } from '~/constants/apps';
import { SUPPORTED_CHART_SERIES, DEFAULT_SETTINGS, SCALE_OPTIONS } from './constants';

const scaleSettings = Object.entries(SCALE_OPTIONS)
  .reduce((settings, [key, scaleOption]) => (
    settings.push(
      Map({
        name: `${key}_min`,
        title: `${scaleOption.label} Min`,
        unitType: scaleOption.unitType,
        unit: scaleOption.unit,
        required: false,
        Editor: textEditorForDefinitions('', scaleOption.min),
        placeholder: 'Auto if not set',
      }),
      Map({
        name: `${key}_max`,
        title: `${scaleOption.label} Max`,
        unitType: scaleOption.unitType,
        unit: scaleOption.unit,
        required: false,
        Editor: textEditorForDefinitions('', scaleOption.max),
        lineBreak: true,
        placeholder: 'Auto if not set',
      }),
    )
  ), List());

export default List([
  Map({
    name: 'graphColors',
    title: 'Graph Colors',
    required: false,
    Editor: chartColorsEditorForDefinitions(SUPPORTED_CHART_SERIES),
  }),
  Map({
    name: 'orientation',
    title: 'Orientation',
    default: DEFAULT_SETTINGS.orientation,
    Editor: radioEditorForDefinitions(ORIENTATION_SETTINGS, DEFAULT_SETTINGS.orientation),
  }),
  Map({
    isCollection: true, // collection of editors
    name: 'scale', // all the scale values are saved under scale : {...}
    title: 'Scale Settings',
    editors: scaleSettings,
  }),
  Map({
    name: 'showFormations',
    title: 'Show Formations',
    required: false,
    default: DEFAULT_SETTINGS.showFormations,
    Editor: switchEditorForDefinitions(DEFAULT_SETTINGS.showFormations),
  }),
]);