import { useState, useEffect } from 'react'
import { AppHeader } from '@corva/ui/components'
import { Checkbox, FormControlLabel, Accordion, AccordionSummary, AccordionDetails, Typography } from '@material-ui/core'
import ExpandMoreIcon from '@material-ui/icons/ExpandMore'
import LightStatus from './components/LightStatus'
import HorizontalBars from './components/HorizontalBars'
import PropTypes from 'prop-types'
import { DEFAULT_SETTINGS, BOXES_NAMES, COLLECTION_INFO } from './constants'
import { useStyles } from './styles'
import { sample_data } from './sample_data'
import logo from './assets/logo.svg'
import { getHistoricalChartData } from './utils/format_data'
// In the next line we import the function that fetch the data from corva collections
// import { fetchCollectionData } from './utils/api'

import { socketClient } from '@corva/ui/clients'

function App(props) {
  const classes = useStyles()
  const { appHeaderProps } = props
  
  // const asset_id = props.wells[0].attributes.asset_id
  const asset_id = COLLECTION_INFO.ASSET_ID

  // const provider = props.currentUser.company.provider
  const provider = COLLECTION_INFO.PROVIDER

  const dataset = COLLECTION_INFO.DATASET

  // This checkbox options are hardcoded because there wasnt enough time to dynamically create them
  const [checkboxesSelection, setCheckboxesSelector] = useState({
    [BOXES_NAMES.overall.id]: true,
    [BOXES_NAMES.flowin_flowout.id]: true,
    [BOXES_NAMES.active_pit.id]: true,
  })

  const [realtimeStatus, setRealtimeStatus] = useState({
    [BOXES_NAMES.overall.id]: 5,
    [BOXES_NAMES.flowin_flowout.id]: 4,
    [BOXES_NAMES.active_pit.id]: 5,
  })

  // In react useState will help you to store your values, everytime a value changes, React will rerender the component that uses that value
  const [categories, setCategories] = useState([])
  const [historicalData, setHistoricalData] = useState([])

  const onBoxOptionSelected = (box_type, value) => {
    setCheckboxesSelector(prevData => {
      const new_value = {
        ...prevData,
        [box_type]: value.target.checked
      }
      return new_value
    })

  }

  // In React useEffect will help you to exec code within different moments of the component lifecycle:
  // Components mounted (first time the component is rendered), component updated (value of state changed), component unmounted (we close the window or change the view to a different component)
  // Simulating realtime data with intervals (setInterval)
  useEffect(() => {
    setInterval(() => {
      setRealtimeStatus({
        [BOXES_NAMES.overall.id]: Math.floor(Math.random() * 5) + 0,
        [BOXES_NAMES.flowin_flowout.id]: Math.floor(Math.random() * 5) + 0,
        [BOXES_NAMES.active_pit.id]: Math.floor(Math.random() * 5) + 0,
      })
    }, 2000)
  }, [])

  // Subscribing to status realtime data
  useEffect(() => {
    let unsubscribe

    const subscription = { 
      asset_id,
      dataset, 
      provider, 
    }

    const onDataReceive = event => setRealtimeStatus(event.data)

    // you need to pass the config values (subscription) and the method that will handle each time we receive new data coing through the subscription
    unsubscribe = socketClient.subscribe(subscription, { onDataReceive })

    return () => unsubscribe() // this is important because will happend when the component gets unmounted, this will prevent you from memory leaks

  }, [])

  // Mocking historical SAMPLE data, comment this useEffect section when trying fetching real time data
  useEffect(() => {
    const { series, y_types } = getHistoricalChartData(sample_data)
    setHistoricalData(series)
    setCategories(y_types)
  }, [])

  // Fetching historical REAL data, uncomment this useEffect section to try real data fetching
  // useEffect(() => {
  //   async function createInitialFetch(){
  //     const data_fetched = await fetchCollectionData({ asset_id, dataset, provider })
  //     setHistoricalData(data_fetched.series)
  //     setCategories(data_fetched.y_types)
  //   }

  //   createInitialFetch()
    
  // }, [])

  return (
    <div className={classes.appContainer}>

      <header className={classes.headerGridItem}>
        <div>
          <img className={classes.headerLogo} src={logo}/>
        </div>
        <div className={classes.headerSplit} />
        <div className={classes.headerContent}>
          <AppHeader {...appHeaderProps} />
        </div>
      </header>

      <main className={classes.mainContainer}>

        {/* This 'filter' section should be an independent component */}
        <section className={classes.checkboxSelector}>
          <Accordion className={classes.accordion}>
            <AccordionSummary
              expandIcon={<ExpandMoreIcon />}
              aria-controls="panel1a-content"
              id="panel1a-header"
            >
              <Typography className={classes.heading}>Selector</Typography>
            </AccordionSummary>
            <AccordionDetails className={classes.accordionDetails}>
              <FormControlLabel
                label={BOXES_NAMES.overall.title}
                control={
                  <Checkbox
                    checked={checkboxesSelection[BOXES_NAMES.overall.id]}
                    onChange={value => onBoxOptionSelected(BOXES_NAMES.overall.id, value)}
                  />
                }
              />
              <FormControlLabel
                label={BOXES_NAMES.flowin_flowout.title}
                control={
                  <Checkbox
                    checked={checkboxesSelection[BOXES_NAMES.flowin_flowout.id]}
                    onChange={value => onBoxOptionSelected(BOXES_NAMES.flowin_flowout.id, value)}
                  />
                }
              />
              <FormControlLabel
                label={BOXES_NAMES.active_pit.title}
                control={
                  <Checkbox
                    checked={checkboxesSelection[BOXES_NAMES.active_pit.id]}
                    onChange={value => onBoxOptionSelected(BOXES_NAMES.active_pit.id, value)}
                  />
                }
              />
            </AccordionDetails>
          </Accordion>
        </section>

        <section className={classes.overallBoxGrid}>
          { 
            checkboxesSelection[BOXES_NAMES.overall.id] && 
            <div className={classes.overallGridItem}>
              <span>{BOXES_NAMES.overall.title}</span>
              <LightStatus status={realtimeStatus[BOXES_NAMES.overall.id]}/>
            </div>
          }
        </section>

        <section className={classes.boxesGrid}>
          {
            checkboxesSelection[BOXES_NAMES.flowin_flowout.id] &&
            <div className={classes.gridItem}>
              <span>{BOXES_NAMES.flowin_flowout.title}</span>
              <LightStatus status={realtimeStatus[BOXES_NAMES.flowin_flowout.id]}/>
            </div>
          }
          {
            checkboxesSelection[BOXES_NAMES.active_pit.id] &&
            <div className={classes.gridItem}>
              <span>{BOXES_NAMES.active_pit.title}</span>
              <LightStatus status={realtimeStatus[BOXES_NAMES.active_pit.id]}/>
            </div>
          }
        </section>

        <section className={classes.historicalBoxGrid}>
          <div className={classes.historicalGridItem}>
            Historical
            <HorizontalBars 
              data={historicalData} 
              categories={categories}
            />
          </div>
        </section>

      </main>
    </div>
  );
}

App.propTypes = {
  isExampleCheckboxChecked: PropTypes.bool,
  appHeaderProps: PropTypes.shape({}).isRequired,
};

App.defaultProps = {
  ...DEFAULT_SETTINGS,
};

// Important: Do not change root component default export (App.js). Use it as container
//  for your App. It's required to make build and zip scripts work as expected;
export default App;
