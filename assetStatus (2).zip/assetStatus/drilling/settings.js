import { List, Map } from 'immutable';

import { switchEditorForDefinitions } from 'components/SwitchEditor';
import { textEditorForDefinitions } from 'components/TextEditor';
import { dropdownEditorForDefinitions } from 'components/DropdownEditor';

import { DEFAULT_SETTINGS, FONT_SIZES } from './constants';

export default List([
  Map({
    name: 'showAssetLink',
    title: 'Show Asset Link',
    Editor: switchEditorForDefinitions(DEFAULT_SETTINGS.showAssetLink),
  }),
  Map({
    name: 'showActivitySummary',
    title: 'Show Activity Summary',
    Editor: switchEditorForDefinitions(DEFAULT_SETTINGS.showActivitySummary),
  }),
  Map({
    name: 'ignoreROPWarning',
    title: 'Ignore ROP channel warning when off-bottom',
    Editor: switchEditorForDefinitions(DEFAULT_SETTINGS.ignoreROPWarning),
  }),
  Map({
    name: 'moderateDataDelay',
    title: 'Moderate Data Delay Threshold',
    required: false,
    Editor: textEditorForDefinitions('', DEFAULT_SETTINGS.moderateDataDelay),
  }),
  Map({
    name: 'severeDataDelay',
    title: 'Severe Data Delay Threshold',
    required: false,
    Editor: textEditorForDefinitions('', DEFAULT_SETTINGS.severeDataDelay),
  }),
  Map({
    name: 'fontSize',
    title: 'Font Size',
    required: false,
    default: DEFAULT_SETTINGS.fontSize,
    Editor: dropdownEditorForDefinitions(FONT_SIZES),
  }),
]);