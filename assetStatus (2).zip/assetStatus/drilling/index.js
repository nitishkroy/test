import Loadable from 'react-loadable';
import { asyncAppLoadableOptions } from '~/utils/loadable';

import AssetStatusAppFooter from './AssetStatusAppFooter';
import settings from './settings';
import * as constants from './meta';

const DrillingAssetStatusApp = Loadable(
  asyncAppLoadableOptions({
    loader: () => import(/* webpackChunkName: "app/corva.asset-status/" */ './AssetStatusApp'),
  })
);

export default {
  AppComponent: DrillingAssetStatusApp,
  AppComponentFooter: AssetStatusAppFooter,
  settings,
  constants,
};