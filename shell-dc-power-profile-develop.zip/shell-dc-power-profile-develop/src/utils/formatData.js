import { maxBy, minBy } from 'lodash'

export function getFormationsSliderMarks(formations) {
    const marks = formations.data.map((formation, idx) => {
        return {
            value: idx,
            label: formation.data.formation_name,
            depth: formation.data.md
        }
    })

    const minDepth = marks[0].value
    const maxDepth = marks[marks.length - 1].value

    return { marks, minDepth, maxDepth }
}

export function getFormationSliderLabel(value, formationSliderMarks){
    if(formationSliderMarks[value]?.depth)
        return formationSliderMarks[value].depth
    else 
        return Infinity
}

export function getMinMaxIntersection(formationSliderMinMaxValues, formationSliderMarks, inputStartMD, inputEndMD){
    const minFormationDepth = getFormationSliderLabel(formationSliderMinMaxValues[0], formationSliderMarks)
    const maxFormationDepth = getFormationSliderLabel(formationSliderMinMaxValues[1], formationSliderMarks)

    const minCustomDepth = Number(inputStartMD)
    const maxCustomDepth = Number(inputEndMD)
    
    return gettingDepthsIntersection(
      { start: minFormationDepth, end: maxFormationDepth },
      { start: minCustomDepth, end: maxCustomDepth }
    )
}

export function gettingDepthsIntersection(a, b){
    //get the range with the smaller starting point (min) and greater start (max)
    const min = (a.start < b.start  ? a : b)
    const max = (min == a ? b : a)

    //min ends before max starts -> no intersection
    if (min.end < max.start)
        return null //the ranges don't intersect

    return { start: max.start , end: min.end < max.end ? min.end : max.end }
}

export function getMinMaxRopMean(data){
    return [
        minBy(data, 'data.rop_mean')?.data.rop_mean,
        maxBy(data, 'data.rop_mean')?.data.rop_mean
    ]
}