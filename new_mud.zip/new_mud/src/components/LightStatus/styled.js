import styled from 'styled-components'

export const Container = styled.div`
    align-items: center;
    display: flex;
    flex-direction: column;
    padding: 1rem;
`

export const Circle = styled.div`
    background-color: ${(({ bgColor }) => bgColor)};
    border-radius: 50%;
    height: 4rem;
    margin: 2rem auto;
    width: 4rem;
`