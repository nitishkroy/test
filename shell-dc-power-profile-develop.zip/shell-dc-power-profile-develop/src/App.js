import { useEffect, useState } from 'react'
import { AppHeader } from '@corva/ui/components'
import PropTypes from 'prop-types'
import { Slider, TextField, Button } from '@material-ui/core'
import Chart from './components/Chart'

import { DEFAULT_SETTINGS, COLLECTION_INFO } from './constants'
import { useStyles } from './styles'
import logo from './assets/logo.svg'
import { fetchFormationsData, fetchWitsData } from './utils/api'
import { createSubscription } from './utils/subscription'
import { 
  getFormationsSliderMarks, 
  getFormationSliderLabel, 
  getMinMaxIntersection,
  getMinMaxRopMean } from './utils/formatData'

function App(props) {
  const { topDriveTorque, topDrivePower, appHeaderProps } = props
  const classes = useStyles()
  const asset_id = COLLECTION_INFO.ASSET_ID
  const [formationSliderMarks, setFormationSliderMarks] = useState([])
  const [formationSliderMinMaxMarks, setFormationSliderMinMaxMarks] = useState([0,10000])
  const [formationSliderMinMaxValues, setFormationSliderMinMaxValues] = useState([0,10000])
  const [inputStartMD, setInputStartMD] = useState(1)
  const [inputEndMD, setInputEndMD] = useState(3000)
  const [witsData, setWitsData] = useState([])
  const [minmaxRopMean, setminmaxRopMean] = useState([0,0])

  useEffect(() => {
    async function fetchFormations() {
      const result = await fetchFormationsData(asset_id)
      
      console.log('result', result)
      if(result?.data.length > 0){
        const { marks, minDepth, maxDepth } = getFormationsSliderMarks(result)
        setFormationSliderMarks(marks)
        setFormationSliderMinMaxMarks([minDepth, maxDepth])
        setFormationSliderMinMaxValues([minDepth, maxDepth])
      }
    }

    fetchFormations()
  
  }, [asset_id])

  useEffect(() => {
    let unsubscribe

    async function subscribeToWits(){
      const minmaxIntersection = getMinMaxIntersection(formationSliderMinMaxValues, formationSliderMarks, inputStartMD, inputEndMD)
      unsubscribe = createSubscription({ 
        asset_id,
        minmaxIntersection,
        updateData,
      })
    }
    
    subscribeToWits()

    return () => {
      unsubscribe?.()
    }

  }, [asset_id])

  const updateData = newData => {
    setWitsData(prevData => {
      if(prevData.length > 0)
        return prevData.concat(newData)
    })
  }

  async function onFilterClick(){

    const minmaxIntersection = getMinMaxIntersection(formationSliderMinMaxValues, formationSliderMarks, inputStartMD, inputEndMD)
      
    console.log('minmaxIntersection', minmaxIntersection)
    if(minmaxIntersection){
      const result = await fetchWitsData(asset_id, minmaxIntersection)
      console.log('result.data', result.data)
      setWitsData(result.data)
      setminmaxRopMean(getMinMaxRopMean(result.data))
    }
    
  }

  return (
    <div className={classes.container}>
      <header className={classes.header}>
          <img className={classes.headerLogo} src={logo}/>
          <div className={classes.headerSplit} />
          <div className={classes.headerContent}>
              <AppHeader {...appHeaderProps} />
              <span className={classes.headerSubtitle}>Ipsum dolor</span>
          </div>
      </header>

      <div className={classes.mainContentGrid}>
          <section className={classes.filtersContainer}>
            <Slider
              value={formationSliderMinMaxValues}
              onChange={(event, newValue) => setFormationSliderMinMaxValues(newValue)}
              aria-labelledby="formations-range-slider"
              valueLabelDisplay="auto"
              valueLabelFormat={(value) => getFormationSliderLabel(value, formationSliderMarks)}
              marks={formationSliderMarks}
              min={formationSliderMinMaxMarks[0]}
              max={formationSliderMinMaxMarks[1]}
              orientation='vertical'
            />
            <div className={classes.depthInputsContainer}>
              <TextField 
                id="start-md" 
                label="Custom Start MD" 
                value={inputStartMD} 
                onChange={(event) => setInputStartMD(event.target.value)} 
                error={!inputStartMD || inputStartMD < 0 || inputStartMD > 30000}
              />
              <TextField 
                id="end-md" 
                label="Custom End MD" 
                value={inputEndMD} 
                onChange={(event) => setInputEndMD(event.target.value)} 
                error={!inputEndMD || inputEndMD < 0 || inputEndMD > 30000}
              />
            </div>

            <div className={classes.filterButtonContainer}>
            <Button variant="contained" color="primary" onClick={() => onFilterClick()}>
              Filter
            </Button>
            </div>
          </section>

          <section className={classes.chartContainer}>
            <Chart 
              wits_data={witsData} 
              top_drive={{ torque: Number(topDriveTorque), power: Number(topDrivePower)}}
              minmax_rop_mean={minmaxRopMean}
            />
          </section>

          <section className={classes.ropaBarContainer}>
              <span>{minmaxRopMean[1]?.toFixed(2)}</span>
              <div className={classes.ropaBar}></div>
              <span>{minmaxRopMean[0]?.toFixed(2)}</span>
          </section>
      </div>
    </div>
  )
}

App.propTypes = {
  topDriveTorque: PropTypes.number,
  topDrivePower: PropTypes.number,
  appHeaderProps: PropTypes.shape({}).isRequired,
}

App.defaultProps = {
  ...DEFAULT_SETTINGS,
}

// Important: Do not change root component default export (App.js). Use it as container
//  for your App. It's required to make build and zip scripts work as expected;
export default App
