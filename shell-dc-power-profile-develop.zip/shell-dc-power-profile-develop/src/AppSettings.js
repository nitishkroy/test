import { TextField } from '@material-ui/core'
import PropTypes from 'prop-types'

import classNames from 'classnames'
import { typography } from '@corva/ui/styles'
import { DEFAULT_SETTINGS } from './constants'
import { useStyles } from './styles'

function AppSettings({ settings: apiSettings, onSettingChange }) {
  const settings = { ...DEFAULT_SETTINGS, ...apiSettings }
  const classes = useStyles()

  return (
    <section className={classes.customSettingsSection}>
      <span className={classNames(typography.regular18, typography.colors.t6)}>Custom settings</span>
      
      <TextField id="Top-Drive-Torque" label="Top Drive Torque" value={settings.topDriveTorque} onChange={(event) => onSettingChange('topDriveTorque', event.target.value)} />
      
      <TextField id="Top-Drive-Power" label="Top Drive Power" value={settings.topDrivePower} onChange={(event) => onSettingChange('topDrivePower', event.target.value)} />
    </section>
  )
}

AppSettings.propTypes = {
  app: PropTypes.shape({}).isRequired,
  appData: PropTypes.shape({}).isRequired,
  company: PropTypes.shape({}),
  onSettingChange: PropTypes.func.isRequired,
  settings: PropTypes.shape({
    topDriveTorque: PropTypes.number,
    topDrivePower: PropTypes.number,
  }).isRequired,
  user: PropTypes.shape({}),
}

AppSettings.defaultProps = {
  user: {},
  company: {},
}

// Important: Do not change root component default export (AppSettings.js). Use it as container
//  for your App Settings. It's required to make build and zip scripts work as expected;
export default AppSettings
