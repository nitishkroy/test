import { makeStyles } from "@material-ui/core"
import { ROPA_COLORS } from './constants'

export const useStyles = makeStyles({
    container: {
        display: 'flex',
        flexDirection: 'column',
        height: '100%',
        overflow: 'scroll',
        padding: '12px 12px 30px 12px'
    },
    header: {
        alignItems: 'center',
        display: 'flex',
        padding: '1rem',
        paddingTop: '0px'
    },
    headerLogo: {
        height: '5rem',
        objectFit: 'contain',
        width: '9rem'
    },
    headerSplit: {
        width: '1px',
        height: '2rem',
        backgroundColor: '#616161',
        margin: '0 1.25rem',
    },
    headerContent: {
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'space-between',
        width: '100%'
    },
    headerSubtitle: {
        color: '#BDBDBD',
        fontSize: '0.75rem'
    },
    customSettingsSection: {
        display: 'flex',
        flexDirection: 'column',
        margin: '2rem 0',
        gap: '1rem',
    },
    mainContentGrid: {
        display: 'grid',
        gridTemplateColumns: '20% 75% 5%',
        gridTemplateRows: 'auto',
    },
    filtersContainer: {
        display: 'flex',
        flexDirection: 'column',
        gap: '2rem',
        gridColumn: 1 / 2,
        minHeight: '40rem',
        padding: '1rem'
    },
    depthInputsContainer: {
        display: 'flex',
        flexDirection: 'column',
        gap: '1rem',
    },
    chartContainer: {
        gridColumn: 2 / 3,
        minHeight: '40rem',
    },
    ropaBarContainer: {
        alignItems: 'center',
        display: 'flex',
        flexDirection: 'column',
        gridColumn: 3 / 4,
        
    },
    ropaBar: {
        backgroundColor: 'red',
        backgroundImage: `linear-gradient(to bottom, ${ROPA_COLORS.join(',')} )`,
        height: '82%',
        width: '2rem'
    }
})