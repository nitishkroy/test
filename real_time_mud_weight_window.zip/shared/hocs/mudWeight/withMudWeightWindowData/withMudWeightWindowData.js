/* eslint-disable react/forbid-prop-types */
/* eslint-disable react/prop-types */
import { forwardRef, useState, useEffect, useRef } from 'react';
import PropTypes from 'prop-types';
import { Map, List } from 'immutable';
import { isEqual } from 'lodash';
import { convertValue } from '@corva/ui/utils';

import * as api from '~/clients/api';
import utils from '~/utils';
import { getSubData } from '~/selectors/subscriptions';

import { mudWeightSubscriptions, mudWeightMetadata } from './mudWeightSubscriptions';

const [
  pressureGradientSubscription,
  pressureLossSubscription,
  witsSubscription,
  mudPlanSubscription,
] = mudWeightSubscriptions;

const MAX_PRESSURE = 20;
const MAX_DATA_POINTS = 4000;

export const MSG_OK = 'ok';
export const MSG_ERROR = 'No Data';
export const MSG_LOADING = 'loading';

const getDataError = (pg, ps, mud) => {
  if (!pg || !ps || !mud) {
    return MSG_LOADING;
  } else if (!ps.getIn(['data', 'ecds']) && pg.isEmpty()) {
    return MSG_ERROR;
  }
  return MSG_OK;
};

export const withMudWeightWindowData = WrappedComponent => {
  const HOC = props => {
    const appKey = props.app.app.app_key;
    const [mudWeightData, setMudWeightData] = useState(null);
    const [alerts, setAlerts] = useState(List());
    const [formations, setFormations] = useState(List());
    const [error, setError] = useState(MSG_LOADING);

    const [alertLoading, setAlertLoading] = useState(false);
    const [formationLoading, setFormationLoading] = useState(false);
    const prevAlertTimeRef = useRef(null);
    const prevFormationTimeRef = useRef(null);

    const maxPressure = Math.round(convertValue(MAX_PRESSURE, 'density', 'ppg'));

    // NOTE: Do not load formation data too often (1 min interval)
    const loadFormations = async () => {
      if (
        prevFormationTimeRef.current &&
        new Date().getTime() - prevFormationTimeRef.current < 1000 * 60
      ) {
        return;
      }

      setFormationLoading(true);
      try {
        const formationsData = await api.getAppStorage(
          mudWeightMetadata.provider,
          mudWeightMetadata.recordCollections.formations,
          props.asset.get('id'),
          Map({ limit: 100 }),
          appKey
        );
        setFormations(formationsData);
      } catch (e) {
        throw new Error(JSON.stringify(e));
      }

      prevFormationTimeRef.current = new Date().getTime();
      setFormationLoading(false);
    };

    // NOTE: Do not load formation data too often (1 min interval)
    const loadAlerts = async (assetId, latestRecord) => {
      if (
        prevFormationTimeRef.current &&
        latestRecord.get('timestamp') - prevFormationTimeRef.current < 60
      ) {
        return;
      }

      setAlertLoading(true);

      const now = latestRecord.get('timestamp');
      const anHourAgo = now - 60 * 60;

      let records;
      try {
        records = await api.getAppStorage(
          pressureLossSubscription.provider,
          pressureLossSubscription.collection,
          assetId,
          Map({
            query: `{timestamp#gte#${anHourAgo}}AND{timestamp#lte#${now}}`,
            limit: 1000,
            fields: 'timestamp,data.alerts',
            sort: '{timestamp: 1}',
          }),
          appKey
        );
      } catch (e) {
        console.error(e);
        return;
      }

      prevAlertTimeRef.current = now;

      setAlerts(records);
      setAlertLoading(false);
    };

    const loadData = async () => {
      // eslint-disable-line consistent-return
      const pressureGradientSub = getSubData(props.data, pressureGradientSubscription, false);
      const pressureLossSub = getSubData(props.data, pressureLossSubscription);
      const mudPlanSub = getSubData(props.data, mudPlanSubscription, false);

      const nextError = getDataError(pressureGradientSub, pressureLossSub, mudPlanSub);
      if (nextError !== MSG_OK) {
        setError(nextError);
        return;
      }
      const witsSub = getSubData(props.data, witsSubscription);

      const holeDepth = witsSub.getIn(['data', 'hole_depth']);
      const casingDepth = pressureLossSub.getIn(['data', 'casing_depth']);

      const spp = convertValue(
        pressureLossSub.getIn(['data', 'standpipe_pressure']),
        'pressure',
        'psi'
      );

      const rop = convertValue(pressureLossSub.getIn(['data', 'rop']), 'velocity', 'ft/h');

      const predictedBottomHolePressure = convertValue(
        pressureLossSub.getIn(['data', 'predicted_annulus_total_pressure_at_bit']),
        'pressure',
        'psi'
      );

      const mwdEcd = convertValue(
        pressureLossSub.getIn(['data', 'mwd_annulus_ecd']),
        'density',
        'ppg'
      );

      const bitDepth = convertValue(pressureLossSub.getIn(['data', 'bit_depth']), 'length', 'ft');

      const flowrate = convertValue(
        pressureLossSub.getIn(['data', 'flowrate']),
        'volumeFlowRate',
        'gal/min'
      );

      const mudDensityVal = convertValue(
        pressureLossSub.getIn(['data', 'mud_density']),
        'density',
        'ppg'
      );

      const currentEcd = convertValue(
        pressureLossSub.getIn(['data', 'predicted_ecd_at_bit']),
        'density',
        'ppg'
      );

      const pgFullData = (pressureGradientSub.first() || Map())
        .getIn(['data', 'records'], List())
        .filter(item => {
          const md = item.get('measured_depth');
          return md <= holeDepth && (!casingDepth || md > casingDepth);
        });
      let pgSubset = pgFullData;
      if (pgFullData.size > MAX_DATA_POINTS) {
        ({ pgSubset } = pgFullData.reduce(
          (data, item) => {
            if (data.shouldRemove && data.countToRemove > 0) {
              return {
                shouldRemove: false,
                countToRemove: data.countToRemove - 1,
                pgSubset: data.pgSubset,
              };
            }
            return {
              shouldRemove: true,
              countToRemove: data.countToRemove,
              pgSubset: data.pgSubset.push(item),
            };
          },
          {
            shouldRemove: false,
            countToRemove: pgFullData.size - MAX_DATA_POINTS,
            pgSubset: List(),
          }
        ));
      }

      const lastMudPlan = (mudPlanSub.first() || Map())
        .getIn(['data', 'records'], List())
        .sortBy(item => item.get('depth'))
        .filter((item, idx) => idx === 0 || item.get('depth') < holeDepth)
        .last();

      const mainData = pgSubset.reduce(
        (pressureGradients, item) => {
          const md = convertValue(item.get('measured_depth'), 'length', 'ft');
          if (pressureGradients.lastWindowMd > md) {
            return pressureGradients;
          }
          const flowV = convertValue(item.get('flow'), 'density', 'ppg');
          const lossV = convertValue(item.get('loss'), 'density', 'ppg');
          const fractureV = convertValue(item.get('fracture'), 'density', 'ppg');
          const collapseV = convertValue(item.get('collapse'), 'density', 'ppg');

          const nextCollapse =
            Number.isFinite(collapseV) && Number.isFinite(flowV) && collapseV > flowV
              ? [...pressureGradients.collapse, [md, flowV, collapseV]]
              : pressureGradients.collapse;

          const nextFlow = Number.isFinite(flowV)
            ? [...pressureGradients.flow, [md, 0, flowV]]
            : pressureGradients.flow;

          let nextSafe;
          let safeMin;
          let safeMax;
          if (
            (Number.isFinite(flowV) || Number.isFinite(collapseV)) &&
            (Number.isFinite(fractureV) || Number.isFinite(lossV))
          ) {
            const y0 = utils.mathMax(flowV, collapseV);
            const y1 = utils.mathMin(fractureV, lossV);
            nextSafe = [...pressureGradients.safe, [md, y0, y1]];
            safeMin = utils.mathMin(y0, pressureGradients.safeMin);
            safeMax = utils.mathMax(y1, pressureGradients.safeMax);
          } else {
            nextSafe = pressureGradients.safe;
          }

          const nextLoss = Number.isFinite(lossV)
            ? [...pressureGradients.loss, [md, lossV, fractureV || maxPressure]]
            : pressureGradients.loss;

          const nextFracture = Number.isFinite(fractureV)
            ? [...pressureGradients.fracture, [md, fractureV, maxPressure]]
            : pressureGradients.fracture;

          return {
            flow: nextFlow,
            loss: nextLoss,
            collapse: nextCollapse,
            fracture: nextFracture,
            safe: nextSafe,
            lastWindowMd: md,
            safeMin,
            safeMax,
          };
        },
        {
          flow: [],
          loss: [],
          fracture: [],
          collapse: [],
          safe: [],
          safeMin: null,
          safeMax: null,
          lastWindowMd: null,
        }
      );

      const indexAfterCasing = pressureLossSub.getIn(['data', 'ecds'], List()).findIndex(item => {
        const md = item.get('measured_depth');
        return !casingDepth || md > casingDepth;
      });

      const { ecds, maxEcd } = pressureLossSub
        .getIn(['data', 'ecds'], List())
        .slice(Math.max(indexAfterCasing - 1, 0))
        .reduce(
          (ecdData, item) => {
            const md = convertValue(item.get('measured_depth'), 'length', 'ft');
            const ecdV = convertValue(item.get('ecd'), 'density', 'ppg');
            return {
              ecds: [...ecdData.ecds, [md, ecdV]],
              maxEcd: utils.mathMax(ecdData.maxEcd, ecdV),
            };
          },
          { ecds: [], maxEcd: null }
        );

      const { loss, flow, safe, fracture, lastWindowMd } = mainData;

      if (ecds.length) {
        const lastEcd = ecds[ecds.length - 1];
        const lastEcdMd = lastEcd[0];

        if (lastWindowMd < lastEcdMd) {
          if (loss.length) {
            const lastLoss = loss[loss.length - 1];
            mainData.loss = [...mainData.loss, [lastEcdMd, lastLoss[1], lastLoss[2]]];
          }

          if (flow.length) {
            const lastFlow = flow[flow.length - 1];
            mainData.flow = [...mainData.flow, [lastEcdMd, lastFlow[1], lastFlow[2]]];
          }

          if (safe.length) {
            const lastSafe = safe[safe.length - 1];
            mainData.safe = [...mainData.safe, [lastEcdMd, lastSafe[1], lastSafe[2]]];
          }

          if (fracture.length) {
            const lastFracture = fracture[fracture.length - 1];
            mainData.fracture = [
              ...mainData.fracture,
              [lastEcdMd, lastFracture[1], lastFracture[2]],
            ];
          }
        }

        mainData.mudDensity = [
          [ecds[0][0], mudDensityVal],
          [utils.mathMax(lastEcdMd, lastWindowMd), mudDensityVal],
        ];
      }

      mainData.flowrate = flowrate;
      mainData.mudDensity = mainData.mudDensity || [];
      mainData.mudDensityVal = mudDensityVal;
      mainData.ecds = ecds;
      mainData.maxEcd = maxEcd;
      mainData.casingDepth = convertValue(casingDepth, 'length', 'ft');
      mainData.currentEcd = currentEcd;
      mainData.spp = spp;
      mainData.rop = rop;
      mainData.predictedBottomHolePressure = predictedBottomHolePressure;
      mainData.bitDepth = bitDepth;
      mainData.mwdEcd = mwdEcd;

      // Draw mud plan when ecds are only available.
      if (lastMudPlan && mainData.mudDensity.length) {
        const lastMd = mainData.mudDensity[1][0];
        const density = convertValue(lastMudPlan.get('mud_density'), 'density', 'ppg');
        mainData.mudPlan = [
          [mainData.casingDepth, density],
          [lastMd, density],
        ];
      }

      setMudWeightData(prev => (isEqual(prev, mainData) ? prev : mainData));
      setError(nextError);

      if (!alertLoading && !formationLoading) {
        // make an api call for alerts history
        await Promise.all([loadAlerts(props.asset.get('id'), pressureLossSub), loadFormations()]);
      }
    };

    useEffect(() => {
      loadData();
    }, [props.data]);

    const { forwardedRef } = props;

    return (
      <WrappedComponent
        ref={forwardedRef}
        mudWeightData={mudWeightData}
        error={error}
        formations={formations}
        alerts={alerts}
        {...props}
      />
    );
  };

  return forwardRef((props, ref) => <HOC {...props} forwardedRef={ref} />);
};

export const mudWeightDataShape = PropTypes.shape({
  bitDepth: PropTypes.number,
  casingDepth: PropTypes.number,
  currentEcd: PropTypes.number,
  flowrate: PropTypes.number,
  lastWindowMd: PropTypes.number,
  maxEcd: PropTypes.number,
  mudDensityVal: PropTypes.number,
  mwdEcd: PropTypes.number,
  predictedBottomHolePressure: PropTypes.number,
  rop: PropTypes.number,
  safeMax: PropTypes.number,
  safeMin: PropTypes.number,
  spp: PropTypes.number,
  collapse: PropTypes.array,
  ecds: PropTypes.array,
  flow: PropTypes.array,
  fracture: PropTypes.array,
  loss: PropTypes.array,
  mudDensity: PropTypes.array,
  safe: PropTypes.array,
});