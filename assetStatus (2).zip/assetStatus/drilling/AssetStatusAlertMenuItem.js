import { PureComponent } from 'react';
import { compose } from 'redux';
import PropTypes from 'prop-types';
import { withRouter } from 'react-router';
import toJS from 'react-immutable-hoc';
import moment from 'moment';

import { withStyles } from '@material-ui/core/styles';

import ListItem from '@material-ui/core/ListItem';
import ListItemIcon from '@material-ui/core/ListItemIcon';
import ListItemText from '@material-ui/core/ListItemText';
import CloseIcon from '@material-ui/icons/Close';

import { setHiddenAlerts } from '~/clients/clientStorage';

import { ALERT_COLORS } from './constants';

const styles = {
  alertIconBar: backgroundColor => ({
    backgroundColor,
    height: 58,
    margin: '1px 0 1px 0',
    right: 5,
    width: 20,
  }),
};

const muiStyles = {
  closeButton: {
    position: 'absolute',
    top: 3,
    right: 5,
    '&:hover': {
      color: 'rgba(0, 0, 0, 0.5)',
    },
  },
  listItem: {
    padding: '0 .5rem',
    cursor: 'pointer',
  },
  listItemText: {
    display: 'flex',
  },
};

class AssetStatusAlertMenuItem extends PureComponent {
  handleAlertSelect = () => this.props.router.push(`/alerts/${this.props.alert.id}`);

  handleAlertDelete = e => {
    e.stopPropagation();
    setHiddenAlerts(this.props.appId, this.props.alert.id, hiddenAlerts => {
      this.props.setHiddenAlerts(hiddenAlerts);
    });
  };

  renderTimeDiff(alertAt, closedAt) {
    const diff = moment(closedAt).diff(moment(alertAt));
    return moment.duration(diff).format('d [day] h [hr] m [min]');
  }

  renderAlertPrimaryInfo = ({ decision_path: decisionPath, alert_definition: { name } }) => (
    <div className="c-asset-status__alert__primary-container">
      <p className="c-asset-status__alert-name">{name}</p>
      <p className="c-asset-status__alert-decision-path">{decisionPath}</p>
    </div>
  );

  renderAlertSecondaryInfo = ({ alert_at: alertAt, closed_at: closedAt }) => (
    <div className="c-asset-status__alert__secondary-container">
      <div className="c-asset-status__alert-time">{moment(alertAt).format('MM/DD/YYYY HH:mm')}</div>
      <div className="c-asset-status__alert-time">+ {this.renderTimeDiff(alertAt, closedAt)}</div>
      <CloseIcon
        classes={{ root: this.props.classes.closeButton }}
        onClick={this.handleAlertDelete}
      />
    </div>
  );

  render = () => (
    <ListItem
      classes={{ root: this.props.classes.listItem }}
      key={this.props.alert.id}
      onClick={this.handleAlertSelect}
    >
      <ListItemIcon>
        <div style={styles.alertIconBar(ALERT_COLORS[this.props.alert.alert_definition.level])} />
      </ListItemIcon>
      <ListItemText
        disableTypography
        primary={this.renderAlertPrimaryInfo(this.props.alert)}
        secondary={this.renderAlertSecondaryInfo(this.props.alert)}
        classes={{ root: this.props.classes.listItemText }}
      />
    </ListItem>
  );
}

AssetStatusAlertMenuItem.propTypes = {
  alert: PropTypes.object.isRequired, // eslint-disable-line react/forbid-prop-types
  classes: PropTypes.object.isRequired, // eslint-disable-line react/forbid-prop-types
  appId: PropTypes.number.isRequired,
  setHiddenAlerts: PropTypes.func.isRequired,
};

export default compose(toJS, withRouter, withStyles(muiStyles))(AssetStatusAlertMenuItem);