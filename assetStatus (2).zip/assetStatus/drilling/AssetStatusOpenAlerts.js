import { PureComponent } from 'react';
import PropTypes from 'prop-types';
import { withRouter } from 'react-router';
import { compose } from 'redux';
import toJS from 'react-immutable-hoc';
import moment from 'moment';
import { withStyles } from '@material-ui/core/styles';

import AlertWarningIcon from '@material-ui/icons/Warning';
import CloseIcon from '@material-ui/icons/Close';
import Chip from '@material-ui/core/Chip';

import { setHiddenAlerts } from '~/clients/clientStorage';

import { ALERT_COLORS } from './constants';

import './AssetStatusOpenAlerts.css';

const muiStyles = {
  closeIcon: {
    position: 'absolute',
    right: 5,
    '&:hover': {
      color: 'rgba(0, 0, 0, 0.5)',
    },
  },
  chip: {
    width: '100%',
    marginBottom: 5,
    cursor: 'pointer',
    position: 'relative',
    paddingRight: 10,
  },
  chipLabel: {
    display: 'flex',
    width: '100%',
  },
  alertIcon: {
    marginRight: 10,
  },
};

class AssetStatusOpenAlerts extends PureComponent {
  get openAlerts() {
    return this.props.alerts.filter(alert => alert.status === 'open');
  }

  handleAlertDelete = (e, alertId) => {
    e.stopPropagation();
    setHiddenAlerts(this.props.appId, alertId, hiddenAlerts => {
      this.props.setHiddenAlerts(hiddenAlerts);
    });
  };

  renderAlert = ({ id, alert_at: alertAt, alert_definition: { level, name } }) => (
    <Chip
      data-not-migrated-MuiChip
      key={id}
      classes={{
        root: this.props.classes.chip,
        label: this.props.classes.chipLabel,
      }}
      style={{ backgroundColor: ALERT_COLORS[level] }}
      onClick={() => this.props.router.push(`/alerts/${id}`)}
      label={
        <>
          <AlertWarningIcon classes={{ root: this.props.classes.alertIcon }} />
          <div className="c-asset-status__open-alert__content">
            <span>{name}</span>
            <span>{moment(alertAt).format('HH:mm')}</span>
            <CloseIcon
              fontSize="small"
              classes={{ root: this.props.classes.closeIcon }}
              onClick={e => this.handleAlertDelete(e, id)}
            />
          </div>
        </>
      }
    />
  );

  render() {
    return (
      <div className="c-asset-status__open-alerts-container">
        {this.openAlerts.map(this.renderAlert)}
      </div>
    );
  }
}

AssetStatusOpenAlerts.propTypes = {
  alerts: PropTypes.arrayOf(PropTypes.object.isRequired).isRequired,
  classes: PropTypes.object.isRequired, // eslint-disable-line react/forbid-prop-types
  appId: PropTypes.number.isRequired,
  setHiddenAlerts: PropTypes.func.isRequired,
};

export default compose(withRouter, withStyles(muiStyles))(toJS(AssetStatusOpenAlerts));