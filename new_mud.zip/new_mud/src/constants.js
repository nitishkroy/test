export const DEFAULT_SETTINGS = {
  isExampleCheckboxChecked: false,
};

export const BOXES_NAMES = {
  overall: {
    title: 'Overall',
    id: 'overall'
  },
  flowin_flowout: {
    title: 'Flowin Flowout',
    id: 'flowin_flowout'
  },
  active_pit: {
    title: 'Active Pit',
    id: 'active_pit'
  },
  historical: {
    title: 'Historical',
    id: 'historical'
  }
}

export const COLLECTION_INFO = {
  ASSET_ID: 41450462, //variable
  COLLECTION: '',
  COMPANY_ID: 80, //variable
  DATASET: '',
  LIMIT: 3000,
  PROVIDER: 'big-data-energy'
}

export const STATUS_INFO = {
  0: {
    color: 'green',
    label: 'Ok'
  },
  1: {
    color: '#FFD500', //#FFD500 yellow
    label: 'Gain (1)'
  },
  2: {
    color: '#ED1C24', //#ED1C24 red
    label: 'Gain (2)'
  },
  3: {
    color: '#FFD500',
    label: 'Loss (3)'
  },
  4: {
    color: '#ED1C24',
    label: 'Loss (4)'
  },
  5: {
    color: '#ED1C24',
    label: 'No data'
  },
}