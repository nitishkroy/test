import { corvaDataAPI } from '@corva/ui/clients'
import { COLLECTION_INFO, API_PATH, WITS_QUERY_FIELDS } from '../constants'

export const fetchFormationsData = async asset_id => {
    let result = []

    const params = {
        fields: ['data.formation_name', 'data.td', 'data.md'].join(','), // getting only the needed values
        limit: COLLECTION_INFO.LIMIT,
        query: JSON.stringify({ asset_id }),
        sort: JSON.stringify({ 'data.td': 1 }), // Sort by td value
    }

    try {
        result = await corvaDataAPI.get(`${API_PATH}/${COLLECTION_INFO.PROVIDER}/${COLLECTION_INFO.DATASET_FORMATIONS}/`, params)
    } 
    catch(error){
        console.log("Error Fetching: ", error)
    }
    finally{
        return { data: result }
    }

}

export const fetchWitsData = async (asset_id, intersection) => {
    let result = []

    const params = {
        fields: WITS_QUERY_FIELDS.join(','), // getting only the needed values
        limit: COLLECTION_INFO.LIMIT,
        query: JSON.stringify({ 
            asset_id,
            'data.hole_depth_mean': { $gt: intersection.start, $lt: intersection.end}
        }),
        sort: JSON.stringify({ 'timestamp': 1 }), // Sort by date
    }

    try {
        result = await corvaDataAPI.get(`${API_PATH}/${COLLECTION_INFO.PROVIDER}/${COLLECTION_INFO.DATASET_WITS}/`, params)
    } 
    catch(error){
        console.log("Error Fetching: ", error)
    }
    finally{
        return { data: result }
    }

}