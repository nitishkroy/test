export const DEFAULT_SETTINGS = {
  topDriveTorque: 105,
  topDrivePower: 1300,
}

export const API_PATH = '/api/v1/data'

export const COLLECTION_INFO = {
  ASSET_ID: 20173768,
  DATASET_FORMATIONS: 'data.formations',
  DATASET_WITS: 'wits.summary-1ft',
  COMPANY_ID: 196,
  LIMIT: 10000,
  PROVIDER: 'corva'
}

export const SERIES = {
  power_100: { 
    color: 'lightblue',
    label: 'Power 100 HP',
    type: 'spline',
    data: [[2,262.6],[4,131.3],[5,105.04],[10,52.52],[15,35.0133333333333],[20,26.26],[22,23.8727272727273],[24,21.8833333333333],[26,20.2],[28,18.7571428571429],[32,16.4125],[40,13.13],[60,8.75333333333333],[80,6.565],[100,5.252],[120,4.37666666666667]]
  },
  power_300: { 
    color: 'orange',
    label: 'Power 300 HP',
    type: 'spline',
    data: [[6,262.6],[8,196.95],[10,157.56],[15,105.04],[20,78.78],[22,71.6181818181818],[24,65.65],[26,60.6],[28,56.2714285714286],[32,49.2375],[40,39.39],[60,26.26],[80,19.695],[100,15.756],[120,13.13],]
  },
  power_500: {
    color: 'gray',
    label: 'Power 500 HP',
    type: 'spline',
    data: [[10,262.6],[15,175.066666666667],[20,131.3],[22,119.363636363636],[24,109.416666666667],[26,101],[28,93.7857142857143],[32,82.0625],[40,65.65],[60,43.7666666666667],[80,32.825],[100,26.26],[120,21.8833333333333]]
  },
  power_1000: {
    color: 'yellow',
    label: 'Power 1000 HP',
    type: 'spline',
    data: [[20,262.6],[22,238.727272727273],[24,218.833333333333],[26,202],[28,187.571428571429],[32,164.125],[40,131.3],[60,87.5333333333333],[80,65.65],[100,52.52],]
  },
  power_1500: {
    color: 'blue',
    label: 'Power 1500 HP',
    type: 'spline',
    data: [[32,246.1875],[40,196.95],[60,131.3],[80,98.475],[100,78.78]]
  },
  top_drive_torque: {
    color: 'green',
    label: 'Top Drive Torque',
    type: 'spline',
    data: [1,5,10,15,20,25,40,50,100,150,200,250]
  },
  wits: {
    color: 'transparent',
    label: 'Wits Summary',
    type: 'scatter'
  },
}

export const TOP_DRIVE_FACTOR = 5.252

export const ROPA_COLORS = ['red', 'orange', 'yellow', 'cyan', 'blue']

export const WITS_QUERY_FIELDS = ['data.hole_depth_mean', 'data.rotary_rpm_mean', 'data.rotary_torque_mean', 'data.rop_mean']
