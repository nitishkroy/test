import { ASSET_TYPES } from '~/constants/assets';

export const CATEGORY = 'asset';
export const NAME = 'assetStatus';
export const SUBSCRIPTIONS = [
  {
    provider: 'corva',
    collection: 'wits',
  },
  {
    /* NOTE: Subscription for new summaries */
    provider: 'corva',
    collection: 'data.operation-summaries',
    meta: {
      allowEmpty: true,
    },
    params: {
      limit: 1000,
      behavior: 'accumulate',
    },
  },
  {
    /* NOTE: Subscription for updated summaries */
    provider: 'corva',
    collection: 'data.operation-summaries',
    event: 'update',
    meta: {
      allowEmpty: true,
    },
  },
];
export const METADATA = {
  segment: ['drilling'],
  title: 'Asset Status',
  disableAppTitle: true,
  settingsTitle: 'Asset Status',
  appKey: 'corva.asset-status',
  fullSize: true,
  disableDisplayAssetName: true,
  developer: { name: 'Corva', url: 'http://www.corva.ai/' },
  recordProvider: 'corva',
  recordCollections: {
    drillstring: 'data.drillstring',
    mud: 'data.mud',
    casing: 'data.casing',
    actualSurvey: 'data.actual_survey',
    summary1m: 'wits.summary-1m',
  },
  version: 'v0.1',
  publishedAt: '2018-05-08T00:00:00',
  lightThemeReport: true,
  supportAnnotations: true,
};
export const PRIMARY_ASSET_TYPE = ASSET_TYPES.getIn(['rig', 'name']);
export const INITIAL_SIZE = { w: 4, h: 10 };