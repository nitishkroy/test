import { corvaDataAPI } from '@corva/ui/clients'

export async function fetchCollectionData({ asset_id, dataset, provider }) {
    try {
      return await corvaDataAPI.get(`/api/v1/data/${provider}/${dataset}/`, {
        limit: 1000,
        skip: 0, // NOTE: Required for pagination
        // NOTE: Make sure the sort field hit database indexes. Otherwise the request will take too long
        sort: JSON.stringify({ timestamp: -1 }),
        query: JSON.stringify({ asset_id: asset_id }),
        // NOTE: To make efficient request - fetch only fields used by the app
        fields: ['timestamp', 'data',].join(','),
      });
    } catch (e) {
        console.log(e)
      return []
    }
}