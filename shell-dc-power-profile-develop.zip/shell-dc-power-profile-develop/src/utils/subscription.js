import { socketClient } from '@corva/ui/clients'
import { COLLECTION_INFO, WITS_QUERY_FIELDS } from '../constants'

export function createSubscription({ asset_id: assetId, minmaxIntersection, updateData }) {
  
  const subscription = { 
    assetId: assetId,
    dataset: COLLECTION_INFO.DATASET_WITS,
    provider: COLLECTION_INFO.PROVIDER,
  }

  const onDataReceive = event => {
    let entries = event.data

    const newData = entries.map(entry => {
        let formattedEntry = {}

        WITS_QUERY_FIELDS.map(field => {
          if(field === 'data.hole_depth_mean'){
            if(entry[field] >= minmaxIntersection.start && entry[field] <= minmaxIntersection.end)
              formattedEntry[field.split('.')[0]] = entry[field]
          }
          else
            formattedEntry[field.split('.')[0]] = entry[field]
        })

        return formattedEntry
    })

    updateData(newData)
  }

  return socketClient.subscribe(subscription, { onDataReceive })
}