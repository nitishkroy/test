import { map, reduce } from "lodash"
import { STATUS_INFO } from '../constants'

// I leave you console logs so you can see the changes in tha values between what you get form the collection and what you need for the Highchart component
// Probably this should be optimized, but there was not enough time! haha, sorry about that

export const getHistoricalChartData = data_collection => {
    let formatted_data = {}

    // For the chart we used, each category represent a value over Y axis
    let categories = reduce(data_collection[0].data, (result, value, key) => {
        if(key !== 'mud_flow_in' && key !== 'mud_flow_out')
            result.push(key)
        return result
    }, [])

    console.log('data_collection', data_collection)
    console.log('categories', categories)

    // So for each category
    categories.map(category => {
        // And for each timelapse within that category, we format the data as follow:
        formatted_data[category] = data_collection.map((item, index) => {
            return {
                category,
                value: item.data[category],
                start_time: item.timestamp * 1000,
                end_time: 
                    index < data_collection.length-1 
                    ? (data_collection[index+1].timestamp) * 1000 
                    : (data_collection[index].timestamp + 2) * 1000 //hardcoding plus 2 seconds
            }
        })
    })

    console.log('formatted_data', formatted_data)

    let all_historic_data = []

    // We join the multiple arrays into a single one, beacuse that what Highcarts needs
    map(formatted_data, category_collection => {
        all_historic_data = all_historic_data.concat(category_collection)
    })
    
    console.log('all_historic_data', all_historic_data)

    // And the last thing to do here is to acctually format the data for Highcharts
    // We group by status all the previous data (each status will have their respective color)
    // With 'x', 'x2' an 'y', Highcharts will know what to do with each timelapse
    let chart_series = map(STATUS_INFO, (status, status_key) => {
        
        return {
            color: status.color,
            data: reduce(all_historic_data, (result, item, key) => {
                if(item.value === parseInt(status_key))
                    result.push({
                        x: item.start_time,
                        x2: item.end_time,
                        y: categories.indexOf(item.category)
                    })

                return result

            }, []),
            name: status.label,
            pointWidth: 33,
        }
    })

    // This is what Highchart needs to work
    console.log('chart_series', chart_series)

    return { series: chart_series, y_types: categories}
}